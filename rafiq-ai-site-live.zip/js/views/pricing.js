// الباقات والعروض وطلب الاشتراك — إعداد وتصميم / فهد مبارك
import { h, icon, openModal, toast } from '../ui.js';
import { t, tr, trList, fmt, getLang } from '../i18n.js';
import * as api from '../api.js';
import { S, priceFor, setting, isAdmin, paymentText } from '../state.js';
import { contactLine } from './legal.js';

const digits = s => String(s || '').replace(/[^\d]/g, '');

export function offerLabel(o) {
  if (Number(o.percent_off) > 0 && !(Number(o.amount_off) > 0)) return t('offer.percent', { n: fmt.num(Number(o.percent_off)) });
  return t('offer.save', { n: fmt.money(Number(o.amount_off || 0)) });
}

export function pricingCards(ctx) {
  const plans = S.catalog.plans;
  const curId = S.status?.plan?.id;
  return h('div', { class: 'plans' }, plans.map(p => {
    const pr = priceFor(p);
    const modes = S.catalog.modes.filter(m => m.min_tier <= p.tier).length;
    const thinks = S.catalog.thinking.filter(m => m.min_tier <= p.tier).length;
    const feats = trList(p.features);
    const label = !S.user ? t('pricing.start') : curId === p.id ? t('pricing.renew') : t('pricing.choose');
    return h('article', { class: 'plan' + (p.highlight ? ' featured' : ''), 'data-plan': p.id },
      p.highlight ? h('span', { class: 'plan-flag' }, icon('star', 14), t('pricing.popular')) : null,
      h('h3', { class: 'plan-name' }, tr(p.name)),
      h('p', { class: 'plan-desc muted' }, tr(p.description)),
      h('div', { class: 'plan-price' },
        h('strong', { class: 'now' }, fmt.money(pr.final)),
        h('span', { class: 'per' }, t('pricing.perYear'))),
      h('div', { class: 'plan-offer' },
        pr.offer ? h('span', { class: 'chip chip-offer' }, icon('tag', 14), offerLabel(pr.offer)) : h('span', { class: 'chip chip-empty' }, ' '),
        pr.discount > 0 ? h('s', { class: 'was', title: t('pricing.listPrice') }, fmt.money(pr.list)) : null),
      h('ul', { class: 'plan-feats' },
        h('li', null, icon('check', 16), h('span', null, t('pricing.daily', { n: fmt.num(p.daily_limit) }))),
        h('li', null, icon('check', 16), h('span', null, t('pricing.modesCount', { n: fmt.num(modes), total: fmt.num(S.catalog.modes.length) }))),
        h('li', null, icon('check', 16), h('span', null, t('pricing.thinkCount', { n: fmt.num(thinks), total: fmt.num(S.catalog.thinking.length) }))),
        feats.map(f => h('li', null, icon('check', 16), h('span', null, f)))),
      h('button', {
        class: 'btn ' + (p.highlight ? 'btn-primary' : 'btn-secondary') + ' btn-block', type: 'button',
        onclick: () => choosePlan(ctx, p),
      }, label));
  }));
}

export function choosePlan(ctx, plan) {
  if (!S.user) { ctx.go('signup?next=' + encodeURIComponent('/pricing?plan=' + plan.id)); return; }
  openCheckout(ctx, plan);
}

export function openCheckout(ctx, plan) {
  const body = h('div', { class: 'checkout' });
  const m = openModal({ title: t('checkout.title'), body, size: 'md' });
  let quote = null, appliedCode = '', method = 'bank';

  const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
  const showErr = msg => { err.textContent = msg; err.hidden = !msg; };

  const codeInput = h('input', { id: 'co-code', class: 'input', placeholder: t('coupon.placeholder'), dir: 'ltr', autocomplete: 'off', maxlength: 30 });
  const codeMsg = h('p', { class: 'hint', 'aria-live': 'polite' });
  const summary = h('div', { class: 'summary' });
  const refInput = h('input', { id: 'co-ref', class: 'input', dir: 'ltr', maxlength: 120, placeholder: t('checkout.reference.ph') });
  const noteInput = h('textarea', { id: 'co-note', class: 'input', rows: 2, maxlength: 500, placeholder: t('checkout.note.ph') });
  const submit = h('button', { class: 'btn btn-primary btn-block', type: 'button' }, t('checkout.submit'));

  function drawSummary() {
    const q = quote;
    summary.replaceChildren(
      h('div', { class: 'sum-row' }, h('span', null, tr(plan.name)), h('span', null, fmt.money(q.list_price))),
      Number(q.discount) > 0 ? h('div', { class: 'sum-row disc' }, h('span', null, icon('tag', 14), tr(q.offer_title) || t('checkout.discount')), h('span', null, '− ' + fmt.money(q.discount))) : null,
      h('div', { class: 'sum-row total' }, h('span', null, t('checkout.total')), h('strong', null, fmt.money(q.final))));
  }
  async function loadQuote(code) {
    try {
      const q = await api.quote(plan.id, code);
      if (!q.ok) throw new Error('no_plan');
      if (code && !q.code_valid) { codeMsg.textContent = t('coupon.invalid'); codeMsg.className = 'hint bad'; return false; }
      quote = q; appliedCode = code || '';
      if (code) { codeMsg.textContent = t('coupon.applied'); codeMsg.className = 'hint good'; } else { codeMsg.textContent = ''; }
      drawSummary(); return true;
    } catch (e) { showErr(t('err.generic')); return false; }
  }

  const methods = [['bank', 'checkout.method.bank'], ['stcpay', 'checkout.method.stcpay'], ['other', 'checkout.method.other']];
  const methodBox = h('div', { class: 'seg', role: 'radiogroup', 'aria-label': t('checkout.method') }, methods.map(([k, label]) =>
    h('button', { type: 'button', class: 'seg-btn' + (k === method ? ' on' : ''), role: 'radio', 'aria-checked': String(k === method), dataset: { m: k },
      onclick: e => { method = k; methodBox.querySelectorAll('.seg-btn').forEach(b => { const on = b.dataset.m === k; b.classList.toggle('on', on); b.setAttribute('aria-checked', String(on)); }); } }, t(label))));

  const instr = paymentText();

  // بيانات الدفع غير مضبوطة بعد: لا نعرض آيبان وهمياً ولا نستقبل طلباً لا يعرف العميل كيف يدفع له
  if (!instr) {
    body.append(
      h('div', { class: 'plan-mini' }, h('strong', null, tr(plan.name)), h('span', { class: 'muted small' }, t('pricing.daily', { n: fmt.num(plan.daily_limit) }))),
      h('div', { class: 'nopay' }, h('span', { class: 'done-ico' }, icon('shield', 26)),
        h('h3', null, t('checkout.noPay.title')), h('p', null, t('checkout.noPay.text')),
        isAdmin() ? h('p', { class: 'hint' }, t('checkout.noPay.admin')) : contactLine(),
        isAdmin() ? h('button', { class: 'btn btn-primary btn-block', type: 'button', onclick: () => { m.close(); ctx.go('admin/settings'); } }, t('checkout.noPay.settings')) : null));
    return;
  }

  body.append(
    h('div', { class: 'plan-mini' }, h('strong', null, tr(plan.name)), h('span', { class: 'muted small' }, t('pricing.daily', { n: fmt.num(plan.daily_limit) })), h('span', { class: 'muted small' }, t('checkout.duration', { n: fmt.num(Math.round(plan.duration_days / 30)) }))),
    summary,
    h('label', { class: 'label', for: 'co-code' }, t('coupon.label')),
    h('div', { class: 'row-inline' }, codeInput, h('button', { class: 'btn btn-secondary', type: 'button', onclick: async () => { showErr(''); const c = codeInput.value.trim(); await loadQuote(c || ''); } }, t('coupon.apply'))),
    codeMsg,
    h('h4', { class: 'sec-title' }, t('checkout.pay.title')),
    instr ? h('div', { class: 'pay-box' }, instr) : null,
    h('span', { class: 'label' }, t('checkout.method')), methodBox,
    h('label', { class: 'label', for: 'co-ref' }, t('checkout.reference')), refInput,
    h('p', { class: 'hint' }, t('checkout.reference.hint')),
    h('label', { class: 'label', for: 'co-note' }, t('checkout.note')), noteInput,
    err, submit,
    h('p', { class: 'hint center' }, t('checkout.manual')));

  submit.addEventListener('click', async () => {
    showErr('');
    const ref = refInput.value.trim();
    if (method !== 'other' && ref.length < 3) { showErr(t('checkout.err.reference')); refInput.focus(); return; }
    submit.disabled = true; submit.textContent = t('common.loading');
    try {
      await api.createOrder({ plan: plan.id, code: appliedCode, method, reference: ref, note: noteInput.value.trim() });
      showDone();
    } catch (e) {
      const map = { invalid_code: 'coupon.invalid', too_many_pending: 'checkout.err.pending', no_plan: 'err.generic', banned: 'banned.title' };
      showErr(t(map[e.code] || 'err.generic'));
      submit.disabled = false; submit.textContent = t('checkout.submit');
    }
  });

  function showDone() {
    const wa = digits(setting('contact_whatsapp', ''));
    const msg = t('checkout.wa.msg', { plan: tr(plan.name), amount: fmt.money(quote.final), ref: refInput.value.trim() || '-' });
    body.replaceChildren(h('div', { class: 'done' },
      h('span', { class: 'done-ico' }, icon('check', 28)),
      h('h3', null, t('checkout.done.title')),
      h('p', null, t('checkout.done.text')),
      wa ? h('a', { class: 'btn btn-secondary btn-block', target: '_blank', rel: 'noopener noreferrer', href: `https://wa.me/${wa}?text=${encodeURIComponent(msg)}` }, icon('whatsapp', 18), t('checkout.wa.btn')) : null,
      h('button', { class: 'btn btn-primary btn-block', type: 'button', onclick: () => { m.close(); ctx.go('account'); } }, t('checkout.done.cta'))));
  }

  loadQuote('');
}

const STEPS = [['pricing.step1.t', 'pricing.step1.d', 'tag'], ['pricing.step2.t', 'pricing.step2.d', 'receipt'], ['pricing.step3.t', 'pricing.step3.d', 'sparkle']];

export function pricingView(ctx) {
  const root = h('div', { class: 'page pricing-page' },
    h('header', { class: 'page-head center' },
      h('h1', null, t('pricing.title')),
      h('p', { class: 'lead' }, t('pricing.sub'))),
    S.catalog.offers.length ? h('div', { class: 'offers' }, S.catalog.offers.map(o => h('div', { class: 'offer-card' },
      h('span', { class: 'offer-ico' }, icon('tag', 20)),
      h('div', null, h('strong', null, tr(o.title)), tr(o.description) ? h('p', { class: 'muted' }, tr(o.description)) : null),
      o.ends_at ? h('span', { class: 'chip' }, t('offer.ends', { date: fmt.date(o.ends_at) })) : null))) : null,
    pricingCards(ctx),
    h('p', { class: 'center muted small' }, t('pricing.note')),
    h('section', { class: 'steps' }, STEPS.map(([a, b, ic], i) => h('div', { class: 'step' },
      h('span', { class: 'step-ico' }, icon(ic, 22)), h('h4', null, t(a)), h('p', { class: 'muted' }, t(b))))));
  const want = ctx.q.get('plan');
  if (want && S.user) {
    const plan = S.catalog.plans.find(p => p.id === want);
    if (plan) setTimeout(() => openCheckout(ctx, plan), 80);
  }
  return root;
}
