// صفحة الحساب والإعدادات — إعداد وتصميم / فهد مبارك
import { h, icon, toast, confirmDialog, downloadFile } from '../ui.js';
import { t, tr, fmt, getLang, LANGS } from '../i18n.js';
import * as api from '../api.js';
import { S, isAdmin, refreshStatus, trialTotal } from '../state.js';

const STATUS_CLASS = { pending: 'warn', approved: 'ok', rejected: 'bad', cancelled: 'muted' };

function card(title, ico, ...kids) {
  return h('section', { class: 'card' }, h('h2', { class: 'card-title' }, icon(ico, 20), title), ...kids);
}
const field = (id, label, input, hint) => h('div', { class: 'field' }, h('label', { class: 'label', for: id }, label), input, hint ? h('p', { class: 'hint' }, hint) : null);

export async function accountView(ctx) {
  await refreshStatus().catch(() => {});
  const orders = await api.myOrders().catch(() => []);
  const st = S.status || {};
  const plan = st.plan;

  // ----- الملف الشخصي
  const nameInput = h('input', { id: 'ac-name', class: 'input', value: S.profile?.full_name || '', maxlength: 80 });
  const saveName = h('button', { class: 'btn btn-primary', type: 'button', onclick: async () => {
    try { S.profile = await api.updateProfile(S.user.id, { full_name: nameInput.value.trim() }); toast(t('account.saved'), 'ok'); } catch { toast(t('err.generic'), 'bad'); }
  } }, t('common.save'));
  const profile = card(t('account.profile'), 'user',
    field('ac-name', t('field.name'), nameInput),
    field('ac-email', t('field.email'), h('input', { id: 'ac-email', class: 'input', value: S.user.email || '', readOnly: true, dir: 'ltr' })),
    saveName);

  // ----- الاشتراك
  let sub;
  if (isAdmin()) {
    sub = card(t('account.subscription'), 'star', h('p', null, t('account.ownerNote')), h('a', { class: 'btn btn-secondary', href: '#/admin' }, icon('gauge', 18), t('nav.admin')));
  } else if (plan) {
    const left = fmt.daysLeft(plan.ends_at);
    sub = card(t('account.subscription'), 'star',
      h('div', { class: 'sub-hero' },
        h('div', null, h('span', { class: 'chip chip-ok' }, t('account.active')), h('h3', null, tr(plan.name))),
        h('div', { class: 'sub-meta' },
          h('div', null, h('span', { class: 'muted' }, t('account.validUntil')), h('strong', null, fmt.date(plan.ends_at))),
          h('div', null, h('span', { class: 'muted' }, t('account.daysLeft')), h('strong', null, fmt.num(left))),
          h('div', null, h('span', { class: 'muted' }, t('account.usedToday')), h('strong', null, `${fmt.num(st.used_today)} / ${fmt.num(plan.daily_limit)}`)))),
      h('a', { class: 'btn btn-secondary', href: '#/pricing' }, t('account.renew')));
  } else {
    sub = card(t('account.subscription'), 'star',
      h('p', null, t('account.noPlan')),
      trialTotal() > 0 ? h('p', { class: 'muted' }, t('account.trialLeft', { n: fmt.num(st.trial_left ?? 0), total: fmt.num(st.trial_total ?? 0) })) : null,
      h('a', { class: 'btn btn-primary', href: '#/pricing' }, t('account.subscribe')));
  }

  // ----- الطلبات
  const ordersBox = h('div', { class: 'orders' });
  function drawOrders(list) {
    ordersBox.replaceChildren(...(list.length ? list.map(o => {
      const plan = S.catalog.plans.find(p => p.id === o.plan_id);
      return h('div', { class: 'order' },
        h('div', { class: 'order-main' },
          h('strong', null, plan ? tr(plan.name) : o.plan_id),
          h('span', { class: 'muted small' }, fmt.datetime(o.created_at)), o.reference ? h('span', { class: 'muted small', style: { unicodeBidi: 'plaintext' } }, '#' + o.reference) : null),
        h('div', { class: 'order-amt' }, fmt.money(o.amount)),
        h('span', { class: 'chip chip-' + (STATUS_CLASS[o.status] || 'muted') }, t('order.status.' + o.status)),
        o.status === 'pending' ? h('button', { class: 'btn btn-ghost btn-sm', type: 'button', onclick: async () => {
          if (!(await confirmDialog(t('order.cancelConfirm'), { okLabel: t('common.confirm'), cancelLabel: t('common.cancel') }))) return;
          try { await api.cancelOrder(o.id); drawOrders(await api.myOrders()); toast(t('account.saved'), 'ok'); } catch { toast(t('err.generic'), 'bad'); }
        } }, t('order.cancel')) : null,
        o.admin_note && o.status === 'rejected' ? h('p', { class: 'order-note muted small' }, o.admin_note) : null);
    }) : [h('p', { class: 'muted' }, t('orders.none'))]));
  }
  drawOrders(orders);
  const ordersCard = card(t('account.orders'), 'receipt', ordersBox);

  // ----- التفضيلات
  const langSel = h('select', { id: 'ac-lang', class: 'input', onchange: e => ctx.changeLanguage(e.target.value) },
    Object.entries(LANGS).filter(([k]) => (api.config.LANGS || Object.keys(LANGS)).includes(k)).map(([k, v]) => h('option', { value: k, selected: k === getLang() }, v.label)));
  const themeSel = h('select', { id: 'ac-theme', class: 'input', onchange: e => { ctx.applyTheme(e.target.value); api.updateProfile(S.user.id, { theme: e.target.value }).then(p => { S.profile = p; }).catch(() => {}); } },
    ['auto', 'light', 'dark'].map(m => h('option', { value: m, selected: m === ctx.currentTheme() }, t('theme.' + m))));
  const savePref = async patch => { try { S.profile = await api.updateProfile(S.user.id, patch); toast(t('account.saved'), 'ok'); } catch { toast(t('err.generic'), 'bad'); } };
  const modeSel = h('select', { id: 'ac-mode', class: 'input', onchange: e => savePref({ default_mode: e.target.value || null }) },
    h('option', { value: '' }, t('account.auto')), S.catalog.modes.map(m => h('option', { value: m.id, selected: S.profile?.default_mode === m.id }, tr(m.name))));
  const thinkSel = h('select', { id: 'ac-think', class: 'input', onchange: e => savePref({ default_thinking: e.target.value || null }) },
    h('option', { value: '' }, t('account.auto')), S.catalog.thinking.map(m => h('option', { value: m.id, selected: S.profile?.default_thinking === m.id }, tr(m.name))));
  const prefs = card(t('account.preferences'), 'settings',
    h('div', { class: 'grid-2' },
      field('ac-lang', t('common.language'), langSel), field('ac-theme', t('common.theme'), themeSel),
      field('ac-mode', t('account.defaultMode'), modeSel), field('ac-think', t('account.defaultThinking'), thinkSel)));

  // ----- الأمان
  const pw = h('input', { id: 'ac-pass', class: 'input', type: 'password', minlength: 6, autocomplete: 'new-password', dir: 'ltr' });
  const security = card(t('account.security'), 'lock',
    field('ac-pass', t('account.newPassword'), pw, t('auth.passwordHint')),
    h('button', { class: 'btn btn-secondary', type: 'button', onclick: async () => {
      if (pw.value.length < 6) { toast(t('err.weak_password'), 'bad'); return; }
      try { await api.auth.setPassword(pw.value); pw.value = ''; toast(t('account.passwordChanged'), 'ok'); } catch (e) { toast(t(api.authErrorKey(e)), 'bad'); }
    } }, t('account.changePassword')));

  // ----- البيانات
  const data = card(t('account.data'), 'download',
    h('p', { class: 'muted' }, t('account.dataNote')),
    h('div', { class: 'row-inline wrap' },
      h('button', { class: 'btn btn-secondary', type: 'button', onclick: async () => {
        try { downloadFile('rafiq-chats.json', JSON.stringify(await api.exportAll(), null, 2)); } catch { toast(t('err.generic'), 'bad'); }
      } }, icon('download', 18), t('account.export')),
      h('button', { class: 'btn btn-danger-ghost', type: 'button', onclick: async () => {
        if (!(await confirmDialog(t('account.deleteHistoryConfirm'), { okLabel: t('common.delete'), cancelLabel: t('common.cancel'), danger: true }))) return;
        try { await api.deleteAllConversations(S.user.id); toast(t('account.deleted'), 'ok'); } catch { toast(t('err.generic'), 'bad'); }
      } }, icon('trash', 18), t('account.deleteHistory'))));

  return h('div', { class: 'page account-page' },
    h('header', { class: 'page-head' }, h('h1', null, t('account.title'))),
    h('div', { class: 'account-grid' }, h('div', { class: 'col' }, profile, sub, ordersCard), h('div', { class: 'col' }, prefs, security, data,
      h('button', { class: 'btn btn-ghost btn-block', type: 'button', onclick: ctx.logout }, icon('logout', 18), t('nav.logout')))));
}
