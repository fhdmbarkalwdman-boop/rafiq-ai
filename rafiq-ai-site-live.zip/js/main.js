// نقطة البداية: الهيكل العام والتوجيه والحسابات — إعداد وتصميم / فهد مبارك
import { h, mount, icon, toast, spinner, clear } from './ui.js';
import { t, tr, setLang, getLang, LANGS, detectLang, fmt } from './i18n.js';
import * as api from './api.js';
import { S, isAdmin, loadUser, clearUser, refreshCatalog, refreshStatus, siteName, setting } from './state.js';

import { landingView } from './views/landing.js';
import { authView } from './views/auth.js';
import { chatView } from './views/chat.js';
import { pricingView } from './views/pricing.js';
import { accountView } from './views/account.js';
import { adminView } from './views/admin.js';
import { legalView } from './views/legal.js';

const ROUTES = {
  home: { view: landingView, title: null },
  login: { view: ctx => authView(ctx, 'login'), title: 'nav.login' },
  signup: { view: ctx => authView(ctx, 'signup'), title: 'nav.signup' },
  forgot: { view: ctx => authView(ctx, 'forgot'), title: 'auth.forgot.title' },
  reset: { view: ctx => authView(ctx, 'reset'), title: 'auth.reset.title' },
  chat: { view: chatView, title: 'nav.chat', auth: true, bare: true },
  pricing: { view: pricingView, title: 'nav.pricing' },
  terms: { view: ctx => legalView(ctx, 'terms'), title: 'legal.terms' },
  privacy: { view: ctx => legalView(ctx, 'privacy'), title: 'legal.privacy' },
  account: { view: accountView, title: 'nav.account', auth: true },
  admin: { view: adminView, title: 'nav.admin', auth: true, admin: true, bare: true },
};

const app = document.getElementById('app');
let viewCleanup = null;
let pendingScroll = null;
let renderToken = 0;

// ---------------------------------------------------------------- التنقّل
export function go(path, scrollTo) {
  pendingScroll = scrollTo || null;
  const target = '#/' + path.replace(/^\/+/, '');
  if (location.hash === target || (target === '#/' && (location.hash === '' || location.hash === '#'))) render();
  else location.hash = target;
}
export function navTo(sectionId) {
  const cur = parseHash();
  if (cur.name === 'home') document.getElementById(sectionId)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  else go('', sectionId);
}
function parseHash() {
  const raw = location.hash;
  if (!raw.startsWith('#/')) return { name: 'home', parts: [], q: new URLSearchParams() };
  const [path, qs] = raw.slice(2).split('?');
  const parts = path.split('/').filter(Boolean).map(decodeURIComponent);
  return { name: parts[0] || 'home', parts: parts.slice(1), q: new URLSearchParams(qs || '') };
}

// ---------------------------------------------------------------- المظهر
function localTheme() { try { return localStorage.getItem('rafiq.theme') || 'auto'; } catch { return 'auto'; } }
export function applyTheme(mode, persist = true) {
  if (!['auto', 'light', 'dark'].includes(mode)) mode = 'auto';
  if (mode === 'auto') document.documentElement.removeAttribute('data-theme'); else document.documentElement.setAttribute('data-theme', mode);
  if (persist) { try { localStorage.setItem('rafiq.theme', mode); } catch { /* ignore */ } }
  const meta = document.querySelector('meta[name=theme-color]');
  if (meta) meta.setAttribute('content', getComputedStyle(document.documentElement).getPropertyValue('--bg').trim() || '#0a7c80');
}
export function currentTheme() { return localTheme(); }

export async function changeLanguage(l) {
  if (l === getLang()) return;
  setLang(l);
  if (S.user && S.profile) { api.updateProfile(S.user.id, { language: l }).then(p => { S.profile = p; }).catch(() => {}); }
  render();
}

// ---------------------------------------------------------------- قوائم منسدلة
let openMenu = null;
function closeMenu() { if (openMenu) { openMenu.remove(); openMenu = null; } }
document.addEventListener('click', e => { if (openMenu && !openMenu.contains(e.target) && !e.target.closest('[data-menu-trigger]')) closeMenu(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(); });
function popover(trigger, items, { align = 'end' } = {}) {
  closeMenu();
  const menu = h('div', { class: 'menu', role: 'menu', style: { insetInlineEnd: align === 'end' ? '0' : 'auto', insetInlineStart: align === 'start' ? '0' : 'auto' } },
    items.map(it => it.sep ? h('hr') : h('button', {
      class: 'menu-item' + (it.active ? ' active' : ''), type: 'button', role: 'menuitem',
      onclick: () => { closeMenu(); it.onClick(); },
    }, it.icon ? icon(it.icon, 18) : null, h('span', null, it.label), it.active ? icon('check', 16) : null)));
  trigger.parentElement.appendChild(menu);
  openMenu = menu;
}

// ---------------------------------------------------------------- الهيكل
function brandLink() {
  return h('a', { class: 'brand', href: '#/', onclick: e => { e.preventDefault(); go(''); } },
    h('span', { class: 'mark', 'aria-hidden': 'true' }, 'ر'),
    h('span', { class: 'brand-name' }, siteName()));
}

function themeButton() {
  const cur = currentTheme();
  const ico = cur === 'dark' ? 'moon' : cur === 'light' ? 'sun' : 'auto';
  const btn = h('button', { class: 'icon-btn', type: 'button', 'aria-label': t('common.theme'), title: t('common.theme') + ': ' + t('theme.' + cur), 'data-menu-trigger': '' }, icon(ico, 18));
  btn.addEventListener('click', () => popover(btn, ['auto', 'light', 'dark'].map(m => ({
    label: t('theme.' + m), icon: m === 'dark' ? 'moon' : m === 'light' ? 'sun' : 'auto', active: m === cur,
    onClick: () => { applyTheme(m); if (S.user) api.updateProfile(S.user.id, { theme: m }).catch(() => {}); render(); },
  }))));
  return h('div', { class: 'menu-host' }, btn);
}

function langButton() {
  const btn = h('button', { class: 'btn btn-ghost btn-sm lang-btn', type: 'button', 'aria-label': t('common.language'), 'data-menu-trigger': '' }, icon('globe', 18), h('span', null, LANGS[getLang()].label));
  btn.addEventListener('click', () => popover(btn, Object.entries(LANGS).filter(([k]) => (api.config.LANGS || Object.keys(LANGS)).includes(k)).map(([k, v]) => ({
    label: v.label, active: k === getLang(), onClick: () => changeLanguage(k),
  }))));
  return h('div', { class: 'menu-host' }, btn);
}

function userMenu() {
  const btn = h('button', { class: 'avatar', type: 'button', 'aria-label': t('nav.account'), 'data-menu-trigger': '' }, (S.profile?.full_name || S.user.email || '?').trim().slice(0, 1).toUpperCase());
  btn.addEventListener('click', () => popover(btn, [
    { label: S.profile?.full_name || S.user.email, icon: 'user', onClick: () => go('account') },
    { sep: true },
    { label: t('nav.chat'), icon: 'chat', onClick: () => go('chat') },
    { label: t('nav.account'), icon: 'settings', onClick: () => go('account') },
    ...(isAdmin() ? [{ label: t('nav.admin'), icon: 'gauge', onClick: () => go('admin') }] : []),
    { sep: true },
    { label: t('nav.logout'), icon: 'logout', onClick: logout },
  ]));
  return h('div', { class: 'menu-host' }, btn);
}

async function logout() {
  try { await api.auth.signOut(); } catch { /* ignore */ }
  clearUser(); go(''); render();
}

function navLinks(route) {
  const link = (label, onClick, active) => h('a', { class: 'nav-link' + (active ? ' active' : ''), href: '#', onclick: e => { e.preventDefault(); onClick(); } }, label);
  if (S.user) {
    return [
      link(t('nav.chat'), () => go('chat'), route === 'chat'),
      link(t('nav.pricing'), () => go('pricing'), route === 'pricing'),
      link(t('nav.account'), () => go('account'), route === 'account'),
      isAdmin() ? link(t('nav.admin'), () => go('admin'), route === 'admin') : null,
    ];
  }
  return [
    link(t('nav.features'), () => navTo('features')),
    link(t('nav.modes'), () => navTo('modes')),
    link(t('nav.pricing'), () => navTo('pricing')),
    link(t('nav.faq'), () => navTo('faq')),
  ];
}

function header(route) {
  const links = h('nav', { class: 'nav', 'aria-label': 'main' }, navLinks(route));
  const actions = h('div', { class: 'header-actions' },
    langButton(), themeButton(),
    S.user ? userMenu() : [
      h('a', { class: 'btn btn-ghost btn-sm hide-sm', href: '#/login' }, t('nav.login')),
      h('a', { class: 'btn btn-primary btn-sm', href: '#/signup' }, t('nav.signup')),
    ]);
  const burger = h('button', { class: 'icon-btn burger', type: 'button', 'aria-label': 'menu', 'aria-expanded': 'false' }, icon('menu', 20));
  const hd = h('header', { class: 'site-header' }, h('div', { class: 'header-in' }, burger, brandLink(), links, actions));
  burger.addEventListener('click', () => {
    const open = hd.classList.toggle('nav-open');
    burger.setAttribute('aria-expanded', String(open));
  });
  links.addEventListener('click', () => hd.classList.remove('nav-open'));
  return hd;
}

function offerBar() {
  const ann = setting('announcement', null);
  const offer = S.catalog.offers[0];
  let text = '', cta = null, ends = null;
  if (ann && ann.enabled && tr(ann.text)) text = tr(ann.text);
  else if (offer && tr(offer.title)) {
    text = tr(offer.title);
    if (offer.ends_at) ends = h('span', { class: 'offer-ends' }, t('offer.ends', { date: fmt.date(offer.ends_at) }));
    cta = h('a', { class: 'offer-cta', href: '#/pricing' }, t('offer.cta'));
  }
  if (!text) return null;
  let dismissed = false; try { dismissed = sessionStorage.getItem('rafiq.bar') === text; } catch { /* ignore */ }
  if (dismissed) return null;
  const bar = h('div', { class: 'offer-bar' }, h('span', { class: 'offer-text' }, icon('tag', 16), text), ends, cta,
    h('button', { class: 'offer-x', type: 'button', 'aria-label': t('common.close'), onclick: () => { try { sessionStorage.setItem('rafiq.bar', text); } catch { /* ignore */ } bar.remove(); } }, icon('close', 14)));
  return bar;
}

function footer() {
  return h('footer', { class: 'site-footer' },
    h('div', { class: 'footer-in' },
      h('div', { class: 'footer-brand' }, h('span', { class: 'mark sm', 'aria-hidden': 'true' }, 'ر'), h('strong', null, siteName()), h('span', { class: 'muted' }, t('brand.tagline'))),
      h('div', { class: 'footer-links' },
        h('a', { href: '#/pricing' }, t('nav.pricing')),
        h('a', { href: S.user ? '#/chat' : '#/login' }, S.user ? t('nav.chat') : t('nav.login')),
        h('a', { href: '#/terms' }, t('legal.terms')),
        h('a', { href: '#/privacy' }, t('legal.privacy'))),
      h('p', { class: 'credit' }, t('footer.credit'))));
}

// ---------------------------------------------------------------- الرسم
async function render() {
  const token = ++renderToken;
  closeMenu();
  if (viewCleanup) { try { viewCleanup(); } catch { /* ignore */ } viewCleanup = null; }
  const ctx0 = parseHash();
  let route = ROUTES[ctx0.name] ? ctx0.name : 'home';
  const def = ROUTES[route];

  // حماية الصفحات
  if (def.auth && !S.user) { const next = encodeURIComponent(location.hash.slice(1) || '/chat'); location.replace('#/login?next=' + next); return; }
  if (def.admin && !isAdmin()) { location.replace('#/chat'); return; }
  if (['login', 'signup', 'forgot'].includes(route) && S.user) { location.replace('#/chat'); return; }
  if (route === 'reset' && !S.user) { location.replace('#/forgot'); return; }

  document.body.dataset.route = route;
  document.body.dataset.bare = def.bare ? '1' : '';
  document.title = (def.title ? t(def.title) + ' | ' : '') + siteName();

  const view = h('main', { id: 'view', class: 'view' }, spinner(t('common.loading')));
  const shell = [offerBar(), header(route), view, def.bare ? null : footer()];
  mount(app, shell);

  const ctx = { ...ctx0, go, navTo, rerender: render, applyTheme, currentTheme, changeLanguage, logout };
  try {
    if (S.status?.banned) throw Object.assign(new Error('banned'), { banned: true });
    const el = await def.view(ctx);
    if (token !== renderToken) return;
    mount(view, el);
    viewCleanup = el && el.cleanup ? el.cleanup : null;
  } catch (e) {
    if (token !== renderToken) return;
    if (!e?.banned) console.error(e);
    mount(view, errorCard(e));
  }
  if (token === renderToken && pendingScroll) {
    const id = pendingScroll; pendingScroll = null;
    setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 60);
  } else if (token === renderToken && !location.hash.includes('/chat')) window.scrollTo(0, 0);
}

function errorCard(e) {
  if (e && e.banned) {
    return h('div', { class: 'center-card' }, h('h2', null, t('banned.title')), h('p', null, t('banned.text')), h('button', { class: 'btn btn-primary', type: 'button', onclick: logout }, t('nav.logout')));
  }
  return h('div', { class: 'center-card' }, h('h2', null, t('common.error')), h('p', { class: 'muted' }, String(e?.message || e)),
    h('button', { class: 'btn btn-primary', type: 'button', onclick: () => render() }, t('common.retry')));
}

// ---------------------------------------------------------------- شاشات خاصة
function renderSetup() {
  const L = getLang() === 'ar' ? 'ar' : 'en';
  const txt = {
    ar: ['الموقع يعمل، لكنه غير مربوط بقاعدة البيانات بعد', 'افتح الملف config.js وضع فيه رابط مشروع Supabase والمفتاح العام (anon / publishable)، ثم ارفع الملف من جديد. خطوات التشغيل كاملة في ملف README.md.'],
    en: ['The site is running but is not connected to a database yet', 'Open config.js and paste your Supabase project URL and public (anon / publishable) key, then upload it again. Full steps are in README.md.'],
  }[L];
  mount(app, h('div', { class: 'center-card setup' }, h('span', { class: 'mark lg', 'aria-hidden': 'true' }, 'ر'), h('h1', null, txt[0]), h('p', null, txt[1]),
    h('pre', { dir: 'ltr' }, 'window.RAFIQ_CONFIG = {\n  SUPABASE_URL: "https://xxxx.supabase.co",\n  SUPABASE_ANON_KEY: "eyJ... / sb_publishable_..."\n};'),
    h('p', { class: 'credit' }, t('footer.credit'))));
}

function renderFatal(e) {
  console.error(e);
  const missing = /get_catalog|schema cache|does not exist|PGRST202|404/i.test(String(e?.message || '') + String(e?.raw?.message || '') + String(e?.raw?.code || ''));
  mount(app, h('div', { class: 'center-card setup' }, h('span', { class: 'mark lg', 'aria-hidden': 'true' }, 'ر'),
    h('h1', null, missing ? t('fatal.schema.title') : t('fatal.net.title')),
    h('p', null, missing ? t('fatal.schema.text') : t('fatal.net.text')),
    h('button', { class: 'btn btn-primary', type: 'button', onclick: () => location.reload() }, t('common.retry')),
    h('p', { class: 'credit' }, t('footer.credit'))));
}

// ---------------------------------------------------------------- الإقلاع
async function boot() {
  const allowed = (api.config.LANGS || Object.keys(LANGS)).filter(l => LANGS[l]);
  setLang(detectLang(allowed, api.config.DEFAULT_LANG || 'ar'), false);
  applyTheme(currentTheme(), false);
  if (!api.configured) return renderSetup();

  mount(app, h('div', { class: 'boot' }, spinner()));
  try { await refreshCatalog(); } catch (e) { return renderFatal(e); }

  // رابط تأكيد البريد/استعادة كلمة المرور يضع الرموز في العنوان؛ نترك المكتبة تقرؤها أولاً
  const session = await api.auth.session();
  if (session) { try { await loadUser(session.user); } catch (e) { return renderFatal(e); } }

  api.sb.auth.onAuthStateChange((event, sess) => {
    setTimeout(async () => {
      try {
        if (event === 'PASSWORD_RECOVERY') { go('reset'); return; }
        if (event === 'SIGNED_IN' && sess) {
          const was = S.user?.id;
          await loadUser(sess.user);
          if (was !== sess.user.id) { await refreshCatalog().catch(() => {}); render(); }
        } else if (event === 'SIGNED_OUT' && S.user) { clearUser(); render(); }
      } catch (e) { console.error(e); }
    }, 0);
  });
  window.addEventListener('hashchange', () => { if (!location.hash.includes('access_token') && !location.hash.includes('type=recovery')) render(); });

  // وصل المستخدم من رابط في بريده (تأكيد الحساب أو استعادة كلمة المرور)
  const link = api.emailLink;
  if (link.error || (link.type === 'recovery' && !session)) {              // رابط منتهي أو غير صالح
    history.replaceState(null, '', location.pathname + location.search + '#/forgot');
    toast(t('err.link_expired'), 'bad', 7000);
    return render();
  }
  if (link.type && session) {
    if (link.type === 'recovery') return go('reset');                       // شاشة كلمة المرور الجديدة
    return go('chat');                                                       // تم تأكيد البريد: ندخله مباشرة
  }
  render();
}

// تبديل المظهر عند تغيّر إعداد النظام
matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', () => { if (currentTheme() === 'auto') applyTheme('auto', false); });

export { render, refreshStatus };
boot();
