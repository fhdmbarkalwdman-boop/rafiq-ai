// الاتصال بقاعدة البيانات والذكاء الاصطناعي — إعداد وتصميم / فهد مبارك
const cfg = window.RAFIQ_CONFIG || {};

export const config = cfg;
export const configured =
  !!cfg.SUPABASE_URL && !!cfg.SUPABASE_ANON_KEY &&
  !/YOUR[-_]/i.test(cfg.SUPABASE_URL) && !/YOUR[-_]/i.test(cfg.SUPABASE_ANON_KEY);

// روابط البريد (تأكيد الحساب / استعادة كلمة المرور) تصل برموز في عنوان الصفحة، والمكتبة تمسحها فور قراءتها
// وتُطلق حدثها قبل أن يشترك التطبيق فيه. لذلك نقرأ نوع الرابط هنا قبل إنشاء العميل.
const linkParams = new URLSearchParams(/^#(?!\/)/.test(location.hash) ? location.hash.slice(1) : '');
export const emailLink = {
  type: linkParams.get('type') || '',                                       // recovery | signup | magiclink ...
  error: linkParams.get('error_code') || linkParams.get('error') || '',     // otp_expired | access_denied ...
};

export const sb = configured && window.supabase
  ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, storageKey: 'rafiq-auth' },
    })
  : null;

export class ApiError extends Error {
  constructor(code, raw) { super(code); this.code = code; this.raw = raw; }
}
export class ChatError extends Error {
  constructor(code, extra = {}) { super(code); this.code = code; this.extra = extra; }
}

const NET_RE = /failed to fetch|networkerror|network request failed|load failed|fetch failed|err_internet|econnrefused|econnreset/i;
function norm(error) {
  const msg = String(error?.message || error?.code || 'unknown').trim();
  if (NET_RE.test(msg)) return new ApiError('network', error);
  return new ApiError(/^[a-z_]+$/.test(msg) ? msg : (error?.code || msg), error);
}
async function rpc(name, args) {
  const { data, error } = await sb.rpc(name, args);
  if (error) throw norm(error);
  return data;
}
async function ok(q) {
  const { data, error } = await q;
  if (error) throw norm(error);
  return data;
}

// ---------- الحساب ----------
export function authErrorKey(err) {
  const code = String(err?.code || err?.error_code || '').toLowerCase();
  const msg = String(err?.message || '').toLowerCase();
  if (code === 'invalid_credentials' || msg.includes('invalid login')) return 'err.invalid_credentials';
  if (code === 'user_already_exists' || msg.includes('already registered') || msg.includes('already been registered')) return 'err.user_exists';
  if (code === 'weak_password' || msg.includes('at least')) return 'err.weak_password';
  if (code === 'email_not_confirmed' || msg.includes('not confirmed')) return 'err.email_not_confirmed';
  if (code.includes('rate_limit') || msg.includes('rate limit') || msg.includes('too many')) return 'err.email_rate';
  if (code === 'validation_failed' || msg.includes('valid email') || msg.includes('invalid email')) return 'err.invalid_email';
  if (msg.includes('fetch') || msg.includes('network')) return 'err.network';
  return 'err.generic';
}
export const auth = {
  async signUp({ email, password, name, lang }) {
    const { data, error } = await sb.auth.signUp({ email, password, options: { data: { full_name: name, language: lang }, emailRedirectTo: location.origin + location.pathname } });
    if (error) throw error;
    return data; // data.session === null  →  يلزم تأكيد البريد
  },
  async signIn({ email, password }) {
    const { data, error } = await sb.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data;
  },
  async signOut() { await sb.auth.signOut(); },
  async reset(email) {
    const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + location.pathname });
    if (error) throw error;
  },
  async setPassword(password) {
    const { error } = await sb.auth.updateUser({ password });
    if (error) throw error;
  },
  session: async () => (await sb.auth.getSession()).data.session,
};

// ---------- بيانات عامة ----------
export const getCatalog = () => rpc('get_catalog');
export const getStatus = () => rpc('my_status');
export const quote = (plan, code) => rpc('quote_price', { p_plan: plan, p_code: code || null });

export async function getProfile(uid) {
  return ok(sb.from('profiles').select('*').eq('id', uid).single());
}
export async function updateProfile(uid, patch) {
  return ok(sb.from('profiles').update(patch).eq('id', uid).select().single());
}

// ---------- المحادثات ----------
export const listConversations = () => ok(sb.from('conversations').select('id,title,mode_id,thinking_id,updated_at').order('updated_at', { ascending: false }).limit(100));
export const createConversation = (uid, mode, thinking) => ok(sb.from('conversations').insert({ user_id: uid, mode_id: mode, thinking_id: thinking }).select('id,title,mode_id,thinking_id,updated_at').single());
export const renameConversation = (id, title) => ok(sb.from('conversations').update({ title: title.slice(0, 80) }).eq('id', id));
export const deleteConversation = id => ok(sb.from('conversations').delete().eq('id', id));
export const loadMessages = id => ok(sb.from('messages').select('id,role,content,created_at').eq('conversation_id', id).order('id', { ascending: true }));
export const deleteAllConversations = uid => ok(sb.from('conversations').delete().eq('user_id', uid));
export async function exportAll() {
  const [conversations, messages] = await Promise.all([
    ok(sb.from('conversations').select('*').order('created_at')),
    ok(sb.from('messages').select('conversation_id,role,content,created_at').order('id')),
  ]);
  return conversations.map(c => ({ ...c, messages: messages.filter(m => m.conversation_id === c.id).map(({ role, content, created_at }) => ({ role, content, created_at })) }));
}

// ---------- الذكاء الاصطناعي (بثّ مباشر) ----------
export async function streamChat({ conversationId, content, mode, thinking, lang, signal, onDelta }) {
  const session = await auth.session();
  if (!session) throw new ChatError('unauthorized');
  let res;
  try {
    res = await fetch(`${cfg.SUPABASE_URL}/functions/v1/chat`, {
      method: 'POST', signal,
      headers: { 'Content-Type': 'application/json', apikey: cfg.SUPABASE_ANON_KEY, Authorization: `Bearer ${session.access_token}` },
      body: JSON.stringify({ conversation_id: conversationId, content, mode, thinking, lang }),
    });
  } catch (e) {
    if (e.name === 'AbortError') throw e;
    throw new ChatError('network');
  }
  if (!res.ok || !(res.headers.get('content-type') || '').includes('event-stream')) {
    let j = {};
    try { j = await res.json(); } catch { /* ignore */ }
    if (res.status === 404 && !j.error) throw new ChatError('function_missing');
    throw new ChatError(j.error || (res.status === 401 ? 'unauthorized' : 'network'), j);
  }
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = '', got = 0, finished = false;
  const handle = block => {
    const line = block.split('\n').find(l => l.startsWith('data:'));
    if (!line) return;
    let ev; try { ev = JSON.parse(line.slice(5).trim()); } catch { return; }
    if (ev.t) { got += ev.t.length; onDelta(ev.t); }
    else if (ev.error) throw new ChatError(ev.error, { partial: !!ev.partial });
    else if (ev.done) finished = true;
  };
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf('\n\n')) >= 0) { handle(buf.slice(0, i)); buf = buf.slice(i + 2); }
    }
  } catch (e) {
    if (e instanceof ChatError || e.name === 'AbortError') throw e;
    throw new ChatError('network', { partial: got > 0 });
  }
  if (buf.trim()) handle(buf);
  if (!finished) throw new ChatError('network', { partial: got > 0 });
}

export async function testAI() {
  const session = await auth.session();
  const res = await fetch(`${cfg.SUPABASE_URL}/functions/v1/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', apikey: cfg.SUPABASE_ANON_KEY, Authorization: `Bearer ${session.access_token}` },
    body: JSON.stringify({ test: true }),
  }).catch(() => null);
  if (!res) return { ok: false, error: 'network' };
  if (res.status === 404) return { ok: false, error: 'function_missing' };
  try { return await res.json(); } catch { return { ok: false, error: 'bad_response', status: res.status }; }
}

// ---------- الطلبات ----------
export const createOrder = o => rpc('create_order', { p_plan: o.plan, p_code: o.code || null, p_method: o.method, p_reference: o.reference || '', p_note: o.note || '' });
export const cancelOrder = id => rpc('cancel_order', { p_order: id });
export const myOrders = () => ok(sb.from('orders').select('*').order('created_at', { ascending: false }).limit(30));

// ---------- لوحة التحكم ----------
export const admin = {
  stats: () => rpc('admin_stats'),
  users: (search = '') => rpc('admin_list_users', { p_search: search, p_limit: 100, p_offset: 0 }),
  setUser: (id, role, banned) => rpc('admin_set_user', { p_user: id, p_role: role, p_banned: banned }),
  grant: (id, plan, days) => rpc('admin_grant_subscription', { p_user: id, p_plan: plan, p_days: days || null }),
  cancelSub: id => rpc('admin_cancel_subscription', { p_user: id }),
  decide: (id, approve, note) => rpc('admin_decide_order', { p_order: id, p_approve: approve, p_note: note || '' }),
  async orders(status) {
    let q = sb.from('orders').select('*').order('created_at', { ascending: false }).limit(200);
    if (status && status !== 'all') q = q.eq('status', status);
    const rows = await ok(q);
    const ids = [...new Set(rows.map(r => r.user_id))];
    const profiles = ids.length ? await ok(sb.from('profiles').select('id,email,full_name').in('id', ids)) : [];
    const byId = Object.fromEntries(profiles.map(p => [p.id, p]));
    return rows.map(r => ({ ...r, user: byId[r.user_id] || null }));
  },
  list: (table, order = 'sort') => ok(sb.from(table).select('*').order(order, { ascending: true })),
  upsert: (table, rec) => ok(sb.from(table).upsert(rec).select()),
  insert: (table, rec) => ok(sb.from(table).insert(rec).select()),
  update: (table, key, val, rec) => ok(sb.from(table).update(rec).eq(key, val).select()),
  remove: (table, key, val) => ok(sb.from(table).delete().eq(key, val)),
  offers: () => ok(sb.from('offers').select('*').order('created_at', { ascending: false })),
  settings: async () => Object.fromEntries((await ok(sb.from('site_settings').select('*'))).map(r => [r.key, r.value])),
  saveSettings: obj => ok(sb.from('site_settings').upsert(Object.entries(obj).map(([key, value]) => ({ key, value })), { onConflict: 'key' })),
};
