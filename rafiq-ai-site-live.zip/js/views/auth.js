// الدخول وإنشاء الحساب واستعادة كلمة المرور — إعداد وتصميم / فهد مبارك
import { h, icon, toast } from '../ui.js';
import { t, getLang } from '../i18n.js';
import * as api from '../api.js';
import { S, loadUser, trialTotal } from '../state.js';

// «بإنشاء حساب فإنك توافق على {terms} و{privacy}» مع الروابط داخل الجملة بأي لغة
function agreeLine() {
  const parts = t('legal.agree').split(/(\{terms\}|\{privacy\})/);
  return h('p', { class: 'hint center agree' }, parts.map(p => p === '{terms}' ? h('a', { href: '#/terms', target: '_blank', rel: 'noopener' }, t('legal.terms'))
    : p === '{privacy}' ? h('a', { href: '#/privacy', target: '_blank', rel: 'noopener' }, t('legal.privacy')) : p));
}

function safeNext(q) {
  const n = q.get('next');
  return n && n.startsWith('/') && !n.startsWith('//') ? n : '/chat';
}

function passwordField(id, autocomplete) {
  const input = h('input', { id, class: 'input', type: 'password', required: true, minlength: 6, autocomplete, dir: 'ltr' });
  const eye = h('button', { class: 'input-eye', type: 'button', 'aria-label': t('auth.showPassword'), onclick: () => { input.type = input.type === 'password' ? 'text' : 'password'; } }, icon('eye', 18));
  return { input, el: h('div', { class: 'input-wrap' }, input, eye) };
}

export function authView(ctx, mode) {
  const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
  const showErr = e => { const key = typeof e === 'string' ? e : api.authErrorKey(e); err.textContent = t(key); err.hidden = false; };
  const submitBtn = label => h('button', { class: 'btn btn-primary btn-block btn-lg', type: 'submit' }, label);
  const busy = (btn, on, label) => { btn.disabled = on; btn.textContent = on ? t('common.loading') : label; };

  const card = h('div', { class: 'auth-card' }, h('span', { class: 'mark lg', 'aria-hidden': 'true' }, 'ر'));
  const wrap = h('div', { class: 'auth-wrap' }, card);
  const field = (id, label, input) => h('div', { class: 'field' }, h('label', { class: 'label', for: id }, label), input);

  if (mode === 'login') {
    const email = h('input', { id: 'a-email', class: 'input', type: 'email', required: true, autocomplete: 'email', dir: 'ltr' });
    const pw = passwordField('a-pass', 'current-password');
    const btn = submitBtn(t('auth.login.btn'));
    const form = h('form', { class: 'form', novalidate: false, onsubmit: async e => {
      e.preventDefault(); err.hidden = true; busy(btn, true);
      try {
        const { user } = await api.auth.signIn({ email: email.value.trim(), password: pw.input.value });
        await loadUser(user);
        ctx.go(safeNext(ctx.q));
      } catch (ex) { showErr(ex); busy(btn, false, t('auth.login.btn')); }
    } }, field('a-email', t('field.email'), email), field('a-pass', t('field.password'), pw.el), err, btn);
    card.append(h('h1', null, t('auth.login.title')), h('p', { class: 'muted' }, t('auth.login.sub')), form,
      h('div', { class: 'auth-links' },
        h('a', { href: '#/forgot' }, t('auth.forgot.link')),
        h('span', null, t('auth.noAccount') + ' ', h('a', { href: '#/signup' + (ctx.q.get('next') ? '?next=' + encodeURIComponent(ctx.q.get('next')) : '') }, t('nav.signup')))));
  }

  if (mode === 'signup') {
    const name = h('input', { id: 'a-name', class: 'input', required: true, maxlength: 80, autocomplete: 'name' });
    const email = h('input', { id: 'a-email', class: 'input', type: 'email', required: true, autocomplete: 'email', dir: 'ltr' });
    const pw = passwordField('a-pass', 'new-password');
    const btn = submitBtn(t('auth.signup.btn'));
    const trial = trialTotal();
    const form = h('form', { class: 'form', onsubmit: async e => {
      e.preventDefault(); err.hidden = true;
      if (pw.input.value.length < 6) { showErr('err.weak_password'); return; }
      busy(btn, true);
      try {
        const data = await api.auth.signUp({ email: email.value.trim(), password: pw.input.value, name: name.value.trim(), lang: getLang() });
        if (data.session) { await loadUser(data.session.user); ctx.go(safeNext(ctx.q)); }
        else {
          card.replaceChildren(h('span', { class: 'done-ico' }, icon('mail', 28)), h('h1', null, t('auth.checkEmail.title')),
            h('p', null, t('auth.checkEmail.text', { email: email.value.trim() })),
            h('a', { class: 'btn btn-secondary btn-block', href: '#/login' }, t('nav.login')));
        }
      } catch (ex) { showErr(ex); busy(btn, false, t('auth.signup.btn')); }
    } }, field('a-name', t('field.name'), name), field('a-email', t('field.email'), email), field('a-pass', t('field.password'), pw.el),
      h('p', { class: 'hint' }, t('auth.passwordHint')), err, btn, agreeLine());
    card.append(h('h1', null, t('auth.signup.title')),
      h('p', { class: 'muted' }, trial > 0 ? t('auth.signup.subTrial', { n: trial }) : t('auth.signup.sub')), form,
      h('div', { class: 'auth-links' }, h('span', null, t('auth.haveAccount') + ' ', h('a', { href: '#/login' + (ctx.q.get('next') ? '?next=' + encodeURIComponent(ctx.q.get('next')) : '') }, t('nav.login')))));
  }

  if (mode === 'forgot') {
    const email = h('input', { id: 'a-email', class: 'input', type: 'email', required: true, autocomplete: 'email', dir: 'ltr' });
    const btn = submitBtn(t('auth.forgot.btn'));
    const form = h('form', { class: 'form', onsubmit: async e => {
      e.preventDefault(); err.hidden = true; busy(btn, true);
      try { await api.auth.reset(email.value.trim()); card.replaceChildren(h('span', { class: 'done-ico' }, icon('mail', 28)), h('h1', null, t('auth.forgot.sentTitle')), h('p', null, t('auth.forgot.sent')), h('a', { class: 'btn btn-secondary btn-block', href: '#/login' }, t('nav.login'))); }
      catch (ex) { showErr(ex); busy(btn, false, t('auth.forgot.btn')); }
    } }, field('a-email', t('field.email'), email), err, btn);
    card.append(h('h1', null, t('auth.forgot.title')), h('p', { class: 'muted' }, t('auth.forgot.sub')), form,
      h('div', { class: 'auth-links' }, h('a', { href: '#/login' }, t('common.back'))));
  }

  if (mode === 'reset') {
    const pw = passwordField('a-pass', 'new-password');
    const btn = submitBtn(t('common.save'));
    const form = h('form', { class: 'form', onsubmit: async e => {
      e.preventDefault(); err.hidden = true; busy(btn, true);
      try { await api.auth.setPassword(pw.input.value); toast(t('account.passwordChanged'), 'ok'); const s = await api.auth.session(); if (s) await loadUser(s.user); ctx.go('chat'); }
      catch (ex) { showErr(ex); busy(btn, false, t('common.save')); }
    } }, field('a-pass', t('account.newPassword'), pw.el), err, btn);
    card.append(h('h1', null, t('auth.reset.title')), h('p', { class: 'muted' }, t('auth.reset.sub')), form);
  }

  return h('div', { class: 'page auth-page' }, wrap);
}
