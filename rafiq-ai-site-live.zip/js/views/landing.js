// الصفحة الرئيسية — إعداد وتصميم / فهد مبارك
import { h, icon } from '../ui.js';
import { t, tr, fmt } from '../i18n.js';
import { S, priceFor, planForTier, trialTotal } from '../state.js';
import { pricingCards } from './pricing.js';

const reduceMotion = () => matchMedia('(prefers-reduced-motion: reduce)').matches;

function hero(ctx, timers) {
  const cheapest = Math.min(...S.catalog.plans.map(p => priceFor(p).final));
  const n = trialTotal();
  const note = n > 0 ? t('hero.note', { n: fmt.num(n), price: fmt.money(cheapest) }) : t('hero.note0', { price: fmt.money(cheapest) });

  const tabs = [['fast', 'bolt'], ['deep', 'brain'], ['critic', 'shield']];
  let current = 'fast';
  const out = h('div', { class: 'demo-a', 'aria-live': 'polite' });
  const tabBox = h('div', { class: 'demo-tabs', role: 'tablist' });
  function type(text) {
    clearInterval(timers.demo);
    out.textContent = '';
    if (reduceMotion()) { out.textContent = text; return; }
    const words = text.split(/(\s+)/);
    let i = 0;
    timers.demo = setInterval(() => {
      out.textContent += words[i++] ?? '';
      if (i >= words.length) clearInterval(timers.demo);
    }, 28);
  }
  function select(k) {
    current = k;
    tabBox.querySelectorAll('button').forEach(b => { const on = b.dataset.k === k; b.classList.toggle('on', on); b.setAttribute('aria-selected', String(on)); });
    type(t('demo.a.' + k));
  }
  tabs.forEach(([k, ic]) => tabBox.appendChild(h('button', { type: 'button', role: 'tab', class: 'demo-tab', dataset: { k }, onclick: () => select(k) }, icon(ic, 16), h('span', null, t('demo.tab.' + k)))));
  setTimeout(() => select('fast'), 50);

  return h('section', { class: 'hero' },
    h('div', { class: 'hero-in' },
      h('div', { class: 'hero-copy' },
        h('span', { class: 'eyebrow' }, icon('sparkle', 16), t('hero.eyebrow')),
        h('h1', null, t('hero.title')),
        h('p', { class: 'lead' }, t('hero.sub')),
        h('div', { class: 'hero-cta' },
          h('a', { class: 'btn btn-primary btn-lg', href: S.user ? '#/chat' : '#/signup' }, S.user ? t('hero.cta.chat') : t('hero.cta')),
          h('button', { class: 'btn btn-ghost btn-lg', type: 'button', onclick: () => ctx.navTo('pricing') }, t('hero.cta2'))),
        h('p', { class: 'hero-note' }, note)),
      h('div', { class: 'demo', 'aria-label': t('hero.demoLabel') },
        h('div', { class: 'demo-label' }, t('hero.demoLabel')),
        h('div', { class: 'demo-q' }, t('demo.q')),
        tabBox, out)));
}

function features() {
  const items = [['feat.modes', 'sparkle'], ['feat.think', 'brain'], ['feat.lang', 'globe'], ['feat.private', 'shield']];
  return h('section', { class: 'section', id: 'features' },
    h('div', { class: 'section-in' },
      h('h2', { class: 'section-title' }, t('features.title')),
      h('div', { class: 'features' }, items.map(([k, ic]) => h('div', { class: 'feature' },
        h('span', { class: 'feature-ico' }, icon(ic, 22)), h('h3', null, t(k + '.t')), h('p', { class: 'muted' }, t(k + '.d')))))));
}

function tierChip(minTier) {
  if (minTier <= 0) return h('span', { class: 'chip chip-free' }, t('tier.free'));
  const p = planForTier(minTier);
  return h('span', { class: 'chip' }, icon('lock', 12), p ? t('tier.from', { plan: tr(p.name) }) : t('tier.locked'));
}

function modesSection() {
  return h('section', { class: 'section alt', id: 'modes' },
    h('div', { class: 'section-in' },
      h('h2', { class: 'section-title' }, t('modes.title')),
      h('p', { class: 'section-sub' }, t('modes.sub')),
      h('div', { class: 'cards-grid' }, S.catalog.modes.map(m => h('div', { class: 'tile' },
        h('span', { class: 'tile-ico' }, icon(m.icon, 22)),
        h('h3', null, tr(m.name)), h('p', { class: 'muted' }, tr(m.description)), tierChip(m.min_tier)))),
      h('h2', { class: 'section-title spaced' }, t('think.title')),
      h('p', { class: 'section-sub' }, t('think.sub')),
      h('div', { class: 'cards-grid' }, S.catalog.thinking.map(m => h('div', { class: 'tile think' },
        h('span', { class: 'tile-ico alt' }, icon(m.icon, 22)),
        h('h3', null, tr(m.name)), h('p', { class: 'muted' }, tr(m.description)), tierChip(m.min_tier))))));
}

function pricingSection(ctx) {
  return h('section', { class: 'section', id: 'pricing' },
    h('div', { class: 'section-in' },
      h('h2', { class: 'section-title' }, t('pricing.title')),
      h('p', { class: 'section-sub' }, t('pricing.sub')),
      pricingCards(ctx),
      h('p', { class: 'center muted small' }, t('pricing.note'))));
}

function faq() {
  return h('section', { class: 'section alt', id: 'faq' },
    h('div', { class: 'section-in narrow' },
      h('h2', { class: 'section-title' }, t('faq.title')),
      [1, 2, 3, 4, 5].map(i => h('details', { class: 'faq' }, h('summary', null, t('faq.q' + i)), h('p', null, t('faq.a' + i))))));
}

function finalCta() {
  return h('section', { class: 'cta-band' },
    h('div', { class: 'section-in center' },
      h('h2', null, t('cta.title')), h('p', null, t('cta.sub')),
      h('a', { class: 'btn btn-light btn-lg', href: S.user ? '#/chat' : '#/signup' }, S.user ? t('hero.cta.chat') : t('hero.cta'))));
}

export function landingView(ctx) {
  const timers = {};
  const root = h('div', { class: 'landing' }, hero(ctx, timers), features(), modesSection(), pricingSection(ctx), faq(), finalCta());
  root.cleanup = () => clearInterval(timers.demo);
  return root;
}
