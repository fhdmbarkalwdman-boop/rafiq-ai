// الحالة المشتركة بين الصفحات — إعداد وتصميم / فهد مبارك
import * as api from './api.js';
import { t, tr, setLang, getLang, LANGS } from './i18n.js';

export const S = {
  user: null,
  profile: null,
  status: null,
  catalog: { plans: [], modes: [], thinking: [], offers: [], settings: {} },
};

export const isAdmin = () => S.status?.role === 'admin' || S.profile?.role === 'admin';
export const userTier = () => (isAdmin() ? 99 : (S.status?.plan?.tier ?? 0));
export const siteName = () => tr(S.catalog.settings.site_name) || t('brand.name');
export const setting = (k, d = '') => S.catalog.settings[k] ?? d;
export const trialTotal = () => Number(setting('trial_messages', 0)) || 0;

// النص التجريبي الذي يأتي مع قاعدة البيانات (آيبان وهمي) لا يُعرض للزوار أبداً
export const PAY_PLACEHOLDER_RE = /SA00 0000|\(اسم البنك\)|bank name/i;
/** أول نص دفع حقيقي: بلغة الواجهة ثم الإنجليزية ثم العربية ثم أي لغة أخرى. النصوص التجريبية لا تُعدّ حقيقية. */
export function realPaymentText(v, lang) {
  const list = typeof v === 'string' ? [v] : [v?.[lang], v?.en, v?.ar, ...Object.values(v || {})];
  return list.map(x => String(x ?? '').trim()).find(x => x.length > 10 && !PAY_PLACEHOLDER_RE.test(x)) || '';
}
export const paymentText = () => realPaymentText(setting('payment_instructions', ''), getLang());
export const paymentReady = () => !!paymentText();

export async function refreshCatalog() { S.catalog = await api.getCatalog(); }
export async function refreshStatus() { S.status = S.user ? await api.getStatus() : null; return S.status; }

let loading = null;
export function loadUser(user) {
  if (S.user && S.user.id === user.id && S.profile && !loading) return Promise.resolve();
  if (loading) return loading;
  S.user = user;
  loading = (async () => {
    try {
      const [profile, status] = await Promise.all([api.getProfile(user.id), api.getStatus()]);
      S.profile = profile; S.status = status;
      if (profile.language && LANGS[profile.language]) setLang(profile.language);
    } finally { loading = null; }
  })();
  return loading;
}
export function clearUser() { S.user = null; S.profile = null; S.status = null; }

/** أفضل عرض تلقائي لباقة (نفس منطق قاعدة البيانات، للعرض فقط؛ السعر النهائي يحسبه الخادم) */
export function priceFor(plan) {
  let best = { discount: 0, offer: null };
  for (const o of S.catalog.offers) {
    if (o.plan_ids && o.plan_ids.length && !o.plan_ids.includes(plan.id)) continue;
    const d = Math.min(Number(plan.price_sar), Math.round((Number(plan.price_sar) * Number(o.percent_off || 0) / 100 + Number(o.amount_off || 0)) * 100) / 100);
    if (d > best.discount) best = { discount: d, offer: o };
  }
  return { list: Number(plan.price_sar), discount: best.discount, final: Math.round((Number(plan.price_sar) - best.discount) * 100) / 100, offer: best.offer };
}

/** أقل باقة تفتح مستوى معيّناً */
export function planForTier(tier) {
  return [...S.catalog.plans].sort((a, b) => a.tier - b.tier).find(p => p.tier >= tier) || null;
}

export function userInitial() {
  const n = (S.profile?.full_name || S.user?.email || '?').trim();
  return n.slice(0, 1).toUpperCase();
}
