// عارض Markdown آمن وخفيف لردود الذكاء الاصطناعي (يهرّب كل شيء قبل أي تنسيق)
// إعداد وتصميم / فهد مبارك

const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');

function inline(s) {
  const stash = [];
  const keep = html => { stash.push(html); return `\u0001${stash.length - 1}\u0001`; };
  s = s.replace(/`([^`\n]+)`/g, (_, c) => keep(`<code>${c}</code>`));
  s = s.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+|mailto:[^\s)]+)\)/g, (_, text, url) =>
    keep(`<a href="${url}" target="_blank" rel="noopener noreferrer nofollow">${text}</a>`));
  s = s.replace(/\*\*([^\n]+?)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/(^|[\s(])\*([^\s*][^*\n]*?)\*(?=$|[\s).,;:!?،؛])/g, '$1<em>$2</em>');
  s = s.replace(/~~([^\n]+?)~~/g, '<del>$1</del>');
  return s.replace(/\u0001(\d+)\u0001/g, (_, i) => stash[+i]);
}

function codeBlock(lang, code) {
  const name = esc(lang || 'text');
  return `<div class="code"><div class="code-head"><span>${name}</span><button type="button" class="code-copy" data-copy-code>COPY</button></div><pre dir="ltr"><code>${code.replace(/\n$/, '')}</code></pre></div>`;
}

const splitRow = line => line.trim().replace(/^\|/, '').replace(/\|$/, '').split('|').map(c => c.trim());
const isSep = line => /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/.test(line) && line.includes('-');

export function renderMarkdown(src) {
  const blocks = [];
  let text = esc(String(src ?? '').replace(/\r\n?/g, '\n')).replace(/```([\w+#.-]*)[^\n]*\n?([\s\S]*?)(```|$)/g, (_, l, c) => {
    blocks.push(codeBlock(l, c));
    return `\n\u0000${blocks.length - 1}\u0000\n`;
  });
  const lines = text.split('\n');
  const out = [];
  let para = [];
  let lists = []; // مكدّس القوائم: {type, indent}
  const flushPara = () => { if (para.length) { out.push('<p>' + inline(para.join('<br>')) + '</p>'); para = []; } };
  const closeLists = (toIndent = -1) => {
    while (lists.length && lists[lists.length - 1].indent > toIndent) out.push(`</li></${lists.pop().type}>`);
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    let m;
    if ((m = line.match(/^\u0000(\d+)\u0000$/))) { flushPara(); closeLists(); out.push(blocks[+m[1]]); continue; }
    if (!line.trim()) { flushPara(); continue; }

    if ((m = line.match(/^(\s*)([-*•]|\d+[.)])\s+(.*)$/)) && !/^(\s*)(-{3,}|\*{3,})\s*$/.test(line)) {
      flushPara();
      const indent = Math.floor(m[1].replace(/\t/g, '  ').length / 2);
      const type = /\d/.test(m[2]) ? 'ol' : 'ul';
      const top = lists[lists.length - 1];
      if (!top || indent > top.indent) { out.push(`<${type}>`); lists.push({ type, indent }); }
      else {
        closeLists(indent);
        const cur = lists[lists.length - 1];
        if (cur && cur.indent === indent && cur.type === type) out.push('</li>');
        else { if (cur) out.push(`</li></${lists.pop().type}>`); out.push(`<${type}>`); lists.push({ type, indent }); }
      }
      out.push('<li>' + inline(m[3]));
      continue;
    }
    if (lists.length && /^\s{2,}\S/.test(line)) { out.push('<br>' + inline(line.trim())); continue; } // استمرار عنصر قائمة
    closeLists();

    if ((m = line.match(/^(#{1,6})\s+(.*)$/))) { flushPara(); const lvl = Math.min(6, m[1].length + 2); out.push(`<h${lvl}>${inline(m[2])}</h${lvl}>`); continue; }
    if (/^\s*([-*_])\1{2,}\s*$/.test(line)) { flushPara(); out.push('<hr>'); continue; }
    if (/^&gt;\s?/.test(line)) {
      flushPara();
      const q = [line.replace(/^&gt;\s?/, '')];
      while (i + 1 < lines.length && /^&gt;\s?/.test(lines[i + 1])) q.push(lines[++i].replace(/^&gt;\s?/, ''));
      out.push('<blockquote>' + inline(q.join('<br>')) + '</blockquote>');
      continue;
    }
    if (line.includes('|') && i + 1 < lines.length && isSep(lines[i + 1])) {
      flushPara();
      const head = splitRow(line);
      const aligns = splitRow(lines[i + 1]).map(c => (c.startsWith(':') && c.endsWith(':') ? 'center' : c.endsWith(':') ? 'right' : c.startsWith(':') ? 'left' : ''));
      i++;
      const rows = [];
      while (i + 1 < lines.length && lines[i + 1].includes('|') && lines[i + 1].trim()) rows.push(splitRow(lines[++i]));
      const cell = (tag, c, idx) => `<${tag}${aligns[idx] ? ` style="text-align:${aligns[idx]}"` : ''}>${inline(c)}</${tag}>`;
      out.push('<div class="table-wrap"><table><thead><tr>' + head.map((c, k) => cell('th', c, k)).join('') + '</tr></thead><tbody>' +
        rows.map(r => '<tr>' + r.map((c, k) => cell('td', c, k)).join('') + '</tr>').join('') + '</tbody></table></div>');
      continue;
    }
    para.push(line);
  }
  flushPara(); closeLists();
  return out.join('');
}
