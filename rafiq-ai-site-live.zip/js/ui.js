// أدوات الواجهة: إنشاء العناصر، الأيقونات، النوافذ، الإشعارات
// إعداد وتصميم / فهد مبارك

const PROP_KEYS = new Set(['value', 'checked', 'disabled', 'selected', 'hidden', 'readOnly', 'indeterminate']);

/** h('div', {class:'x', onclick: fn}, 'text', child, [children]) */
export function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v === null || v === undefined || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k === 'dataset') Object.assign(el.dataset, v);
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (PROP_KEYS.has(k)) el[k] = v;
      else el.setAttribute(k, v === true ? '' : String(v));
    }
  }
  append(el, kids);
  return el;
}

export function append(el, kids) {
  for (const k of kids) {
    if (k === null || k === undefined || k === false || k === true) continue;
    if (Array.isArray(k)) append(el, k);
    else if (k instanceof Node) el.appendChild(k);
    else el.appendChild(document.createTextNode(String(k)));
  }
  return el;
}

export function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }
export function mount(el, ...kids) { clear(el); append(el, kids); return el; }

// ---------- الأيقونات (SVG بخط) ----------
const ICONS = {
  chat: 'M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.2A8 8 0 1 1 21 12z',
  pen: 'M4 20l1-4L16.5 4.5a2.1 2.1 0 0 1 3 3L8 19l-4 1z M14 7l3 3',
  globe: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z M3 12h18 M12 3c2.5 2.6 3.8 5.6 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z',
  list: 'M8 6h12 M8 12h12 M8 18h12 M4 6h.01 M4 12h.01 M4 18h.01',
  book: 'M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5v-16z M4 19.5A2.5 2.5 0 0 1 6.5 17H20',
  code: 'M8 8l-5 4 5 4 M16 8l5 4-5 4 M14 5l-4 14',
  briefcase: 'M3 8h18v11H3z M9 8V6a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2 M3 13h18',
  chart: 'M4 20V10 M10 20V4 M16 20v-7 M22 20H2',
  bolt: 'M13 2L4 14h7l-1 8 9-12h-7l1-8z',
  scale: 'M12 3v18 M6 21h12 M5 7h14 M5 7l-3 7a3 3 0 0 0 6 0L5 7z M19 7l-3 7a3 3 0 0 0 6 0l-3-7z',
  steps: 'M3 20h5v-5h5v-5h5V5h3',
  question: 'M9.5 9a2.6 2.6 0 1 1 3.6 2.4c-.8.4-1.1 1-1.1 1.8 M12 17h.01 M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18z',
  brain: 'M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 5 1V4a3 3 0 0 0-2 0z M15 4a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-5 1V4a3 3 0 0 1 2 0z',
  search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16z M21 21l-4.3-4.3',
  shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z M9 12l2 2 4-4',
  users: 'M17 20v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2 M10 10a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M21 20v-2a4 4 0 0 0-3-3.9 M16 2.1a4 4 0 0 1 0 7.8',
  lock: 'M5 11h14v10H5z M8 11V7a4 4 0 0 1 8 0v4',
  check: 'M5 12.5l4.5 4.5L19 7.5',
  copy: 'M9 9h11v11H9z M5 15H4V4h11v1',
  send: 'M3 11l18-8-8 18-2-8-8-2z',
  stop: 'M6 6h12v12H6z',
  menu: 'M4 6h16 M4 12h16 M4 18h16',
  plus: 'M12 5v14 M5 12h14',
  trash: 'M4 7h16 M10 11v6 M14 11v6 M6 7l1 13h10l1-13 M9 7V4h6v3',
  edit: 'M4 20h4L19 9l-4-4L4 16v4z M13.5 6.5l4 4',
  sun: 'M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M12 2v2 M12 20v2 M4.9 4.9l1.4 1.4 M17.7 17.7l1.4 1.4 M2 12h2 M20 12h2 M4.9 19.1l1.4-1.4 M17.7 6.3l1.4-1.4',
  moon: 'M21 13.5A8.5 8.5 0 1 1 10.5 3a6.5 6.5 0 0 0 10.5 10.5z',
  auto: 'M3 5h18v11H3z M8 20h8 M12 16v4',
  user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8z M4 21a8 8 0 0 1 16 0',
  logout: 'M9 4H5v16h4 M16 8l4 4-4 4 M20 12H9',
  settings: 'M4 6h10 M18 6h2 M4 12h4 M12 12h8 M4 18h12 M20 18h0 M16 4v4 M10 10v4 M18 16v4',
  star: 'M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9L12 3z',
  tag: 'M3 12V4h8l10 10-8 8L3 12z M7.5 8.5h.01',
  close: 'M6 6l12 12 M18 6L6 18',
  chevron: 'M6 9l6 6 6-6',
  download: 'M12 4v11 M7 11l5 5 5-5 M4 20h16',
  receipt: 'M6 3h12v18l-3-2-3 2-3-2-3 2V3z M9 8h6 M9 12h6',
  gauge: 'M4 13a8 8 0 0 1 16 0 M12 13l4-4 M4 17h16',
  home: 'M3 11l9-8 9 8 M5 10v10h14V10',
  sparkle: 'M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3z',
  arrow: 'M5 12h14 M13 6l6 6-6 6',
  mail: 'M3 5h18v14H3z M3 7l9 6 9-6',
  eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
  whatsapp: 'M20 12a8 8 0 0 1-11.8 7L4 20l1.1-4A8 8 0 1 1 20 12z M9 9c0 3 3 6 6 6l1-1.5-2-1-1 .8c-1-.4-2-1.4-2.4-2.4l.8-1-1-2L9 9z',
};

export function icon(name, size = 20) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('width', size);
  svg.setAttribute('height', size);
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '1.8');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('class', 'ico ico-' + name);
  const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  path.setAttribute('d', ICONS[name] || ICONS.sparkle);
  svg.appendChild(path);
  return svg;
}
export const ICON_NAMES = Object.keys(ICONS).filter(n => !['menu', 'close', 'chevron', 'send', 'stop', 'copy', 'check', 'plus', 'trash', 'edit', 'sun', 'moon', 'auto', 'logout', 'download', 'arrow', 'eye', 'home', 'mail', 'whatsapp', 'lock', 'tag', 'receipt', 'gauge', 'settings', 'user'].includes(n));

// ---------- إشعارات ----------
let toastBox;
export function toast(message, type = 'info', ms = 3800) {
  if (!toastBox) {
    toastBox = h('div', { class: 'toasts', 'aria-live': 'polite', role: 'status' });
    document.body.appendChild(toastBox);
  }
  const el = h('div', { class: 'toast toast-' + type }, message);
  toastBox.appendChild(el);
  setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 250); }, ms);
}

// ---------- نوافذ ----------
export function openModal({ title, body, footer, size = 'md', onClose, sheet = false }) {
  const prevFocus = document.activeElement;
  const closeBtn = h('button', { class: 'icon-btn', type: 'button', 'aria-label': '×', onclick: () => close() }, icon('close', 18));
  const dialog = h('div', { class: `modal modal-${size}${sheet ? ' sheet' : ''}`, role: 'dialog', 'aria-modal': 'true' },
    h('div', { class: 'modal-head' }, h('h3', null, title || ''), closeBtn),
    h('div', { class: 'modal-body' }, body),
    footer ? h('div', { class: 'modal-foot' }, footer) : null);
  const backdrop = h('div', { class: 'backdrop', onmousedown: e => { if (e.target === backdrop) close(); } }, dialog);
  const onKey = e => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
  function close() {
    document.removeEventListener('keydown', onKey, true);
    backdrop.remove();
    document.body.classList.remove('no-scroll');
    if (prevFocus && prevFocus.focus) try { prevFocus.focus(); } catch { /* ignore */ }
    if (onClose) onClose();
  }
  document.addEventListener('keydown', onKey, true);
  document.body.appendChild(backdrop);
  document.body.classList.add('no-scroll');
  const first = dialog.querySelector('input:not([type=hidden]), textarea, select, button.btn-primary');
  // تركيز أول حقل بعد ظهور النافذة، لكن دون سحب التركيز إن كان المستخدم قد بدأ فعلاً بالكتابة في حقل آخر داخلها
  setTimeout(() => { if (!dialog.contains(document.activeElement)) (first || closeBtn).focus(); }, 30);
  return { close, el: dialog, backdrop };
}

export function confirmDialog(message, { okLabel, cancelLabel, danger = false, title = '' } = {}) {
  return new Promise(resolve => {
    let done = false;
    const finish = v => { if (!done) { done = true; resolve(v); } };
    const m = openModal({
      title, size: 'sm', body: h('p', { class: 'confirm-text' }, message),
      onClose: () => finish(false),
      footer: [
        h('button', { class: 'btn btn-ghost', type: 'button', onclick: () => { finish(false); m.close(); } }, cancelLabel),
        h('button', { class: 'btn ' + (danger ? 'btn-danger' : 'btn-primary'), type: 'button', onclick: () => { finish(true); m.close(); } }, okLabel),
      ],
    });
  });
}

export function spinner(label) { return h('div', { class: 'spinner-wrap' }, h('span', { class: 'spinner', 'aria-hidden': 'true' }), label ? h('span', null, label) : null); }

export function debounce(fn, ms = 300) { let id; return (...a) => { clearTimeout(id); id = setTimeout(() => fn(...a), ms); }; }

export function copyText(text) {
  return navigator.clipboard.writeText(text).catch(() => {
    const ta = h('textarea', { style: { position: 'fixed', opacity: '0' } });
    ta.value = text; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); } finally { ta.remove(); }
  });
}

export function downloadFile(name, text, type = 'application/json') {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = h('a', { href: url, download: name });
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export const sleep = ms => new Promise(r => setTimeout(r, ms));
