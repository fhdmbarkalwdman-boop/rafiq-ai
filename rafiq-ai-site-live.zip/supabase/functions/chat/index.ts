// =====================================================================
//  رفيق | Rafiq AI — دالة الذكاء الاصطناعي (Supabase Edge Function)
//  إعداد وتصميم / فهد مبارك
//
//  ملف واحد جاهز للصق في: Supabase → Edge Functions → Deploy a new function
//  اسم الدالة يجب أن يكون:  chat
//
//  الأسرار (Edge Functions → Secrets):
//    AI_API_KEY       مفتاح المزوّد (إلزامي)
//    AI_PROVIDER      anthropic (الافتراضي) | openai | gemini | openrouter | groq | deepseek
//    AI_MODEL         اسم النموذج السريع (اختياري، له قيمة افتراضية)
//    AI_MODEL_SMART   اسم النموذج الأقوى لأنظمة التفكير العميق (اختياري)
//    AI_BASE_URL      عنوان بديل للمزوّد (اختياري)
//
//  ماذا تفعل الدالة؟
//   1) تتحقق من هوية المستخدم   2) تتحقق من الاشتراك والحد اليومي والأنماط (في قاعدة البيانات)
//   3) تستدعي المزوّد وتبثّ الرد مباشرة   4) تحفظ المحادثة   5) تعيد الرسالة إن فشل المزوّد
// =====================================================================

import { createClient } from "npm:@supabase/supabase-js@2";

// ---------- الإعدادات ----------

const CORS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Max-Age": "86400",
};

const PRESETS: Record<string, { base: string; model: string }> = {
  anthropic: { base: "https://api.anthropic.com", model: "claude-haiku-5-5" },
  openai: { base: "https://api.openai.com/v1", model: "gpt-4o-mini" },
  gemini: { base: "https://generativelanguage.googleapis.com/v1beta/openai", model: "gemini-2.5-flash" },
  openrouter: { base: "https://openrouter.ai/api/v1", model: "openai/gpt-4o-mini" },
  groq: { base: "https://api.groq.com/openai/v1", model: "llama-3.3-70b-versatile" },
  deepseek: { base: "https://api.deepseek.com", model: "deepseek-chat" },
};

const LANG_NAME: Record<string, string> = {
  ar: "العربية (Arabic)",
  en: "English",
  fr: "Français (French)",
  ur: "اردو (Urdu)",
};

const ERROR_STATUS: Record<string, number> = {
  subscription_required: 402,
  daily_limit: 429,
  locked_mode: 403,
  locked_thinking: 403,
  banned: 403,
  no_conversation: 404,
  no_profile: 403,
  empty: 400,
  too_long: 400,
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function firstKey(json: string | undefined | null): string | undefined {
  if (!json) return undefined;
  try {
    const o = JSON.parse(json);
    const v = o.default ?? Object.values(o)[0];
    return typeof v === "string" ? v : undefined;
  } catch {
    return undefined;
  }
}

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SERVICE_KEY =
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || firstKey(Deno.env.get("SUPABASE_SECRET_KEYS")) || "";

const admin = createClient(SUPABASE_URL, SERVICE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false },
});

function aiConfig() {
  const provider = (Deno.env.get("AI_PROVIDER") || "anthropic").trim().toLowerCase();
  const preset = PRESETS[provider] ?? PRESETS.openai;
  const key = (Deno.env.get("AI_API_KEY") || "").trim();
  const model = (Deno.env.get("AI_MODEL") || preset.model).trim();
  const smart = (Deno.env.get("AI_MODEL_SMART") || model).trim();
  let base = (Deno.env.get("AI_BASE_URL") || preset.base).trim().replace(/\/+$/, "");
  if (provider === "anthropic") base = base.replace(/\/v1$/, "");
  return { provider, anthropic: provider === "anthropic", key, model, smart, base };
}
type AIConfig = ReturnType<typeof aiConfig>;
type Msg = { role: "user" | "assistant"; content: string };

// ---------- أدوات صغيرة ----------

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json; charset=utf-8" },
  });
}

class AIError extends Error {
  constructor(public code: string, public status: number, public detail: string) {
    super(detail);
  }
}

function codeForStatus(status: number): string {
  if (status === 401 || status === 403) return "ai_auth";
  if (status === 429) return "ai_rate";
  if (status >= 500) return "ai_unavailable";
  return "ai_error";
}

async function throwFromResponse(res: Response): Promise<never> {
  let detail = "";
  try {
    const text = await res.text();
    try {
      const j = JSON.parse(text);
      detail = j?.error?.message || j?.message || j?.error || text;
    } catch {
      detail = text;
    }
  } catch { /* ignore */ }
  throw new AIError(codeForStatus(res.status), res.status, String(detail).slice(0, 300));
}

// يقرأ تدفق SSE ويعيد الأحداث واحداً واحداً
async function* sseEvents(res: Response): AsyncGenerator<{ event?: string; data: string }> {
  const reader = res.body!.getReader();
  const dec = new TextDecoder();
  let buf = "";
  const parse = (raw: string) => {
    let event: string | undefined;
    const data: string[] = [];
    for (const line of raw.split(/\r?\n/)) {
      if (line.startsWith("event:")) event = line.slice(6).trim();
      else if (line.startsWith("data:")) data.push(line.slice(5).replace(/^ /, ""));
    }
    return data.length ? { event, data: data.join("\n") } : null;
  };
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let m: RegExpExecArray | null;
      while ((m = /\r?\n\r?\n/.exec(buf))) {
        const ev = parse(buf.slice(0, m.index));
        buf = buf.slice(m.index + m[0].length);
        if (ev) yield ev;
      }
    }
    buf += dec.decode();
    if (buf.trim()) {
      const ev = parse(buf);
      if (ev) yield ev;
    }
  } finally {
    try { reader.releaseLock(); } catch { /* ignore */ }
  }
}

// ---------- مزوّدو الذكاء الاصطناعي (يعيدون النص قطعة قطعة) ----------

async function* streamAnthropic(
  cfg: AIConfig, model: string, system: string, messages: Msg[], maxTokens: number, signal: AbortSignal,
): AsyncGenerator<string> {
  const res = await fetch(`${cfg.base}/v1/messages`, {
    method: "POST",
    signal,
    headers: { "content-type": "application/json", "x-api-key": cfg.key, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model, max_tokens: maxTokens, system, messages, stream: true }),
  });
  if (!res.ok) await throwFromResponse(res);
  for await (const ev of sseEvents(res)) {
    let j: any;
    try { j = JSON.parse(ev.data); } catch { continue; }
    if (j.type === "content_block_delta" && j.delta?.type === "text_delta" && j.delta.text) {
      yield j.delta.text as string;
    } else if (j.type === "error") {
      throw new AIError("ai_error", 500, String(j.error?.message ?? "stream error").slice(0, 300));
    } else if (j.type === "message_stop") {
      return;
    }
  }
}

async function* streamOpenAI(
  cfg: AIConfig, model: string, system: string, messages: Msg[], maxTokens: number, signal: AbortSignal,
): AsyncGenerator<string> {
  const isOpenAI = cfg.base.includes("api.openai.com");
  const body: Record<string, unknown> = {
    model,
    stream: true,
    messages: [{ role: "system", content: system }, ...messages],
  };
  body[isOpenAI ? "max_completion_tokens" : "max_tokens"] = maxTokens;
  const res = await fetch(`${cfg.base}/chat/completions`, {
    method: "POST",
    signal,
    headers: { "content-type": "application/json", authorization: `Bearer ${cfg.key}` },
    body: JSON.stringify(body),
  });
  if (!res.ok) await throwFromResponse(res);
  for await (const ev of sseEvents(res)) {
    if (ev.data.trim() === "[DONE]") return;
    let j: any;
    try { j = JSON.parse(ev.data); } catch { continue; }
    if (j.error) throw new AIError("ai_error", 500, String(j.error.message ?? j.error).slice(0, 300));
    const t = j.choices?.[0]?.delta?.content;
    if (typeof t === "string" && t) yield t;
  }
}

function streamAI(
  cfg: AIConfig, model: string, system: string, messages: Msg[], maxTokens: number, signal: AbortSignal,
) {
  return cfg.anthropic
    ? streamAnthropic(cfg, model, system, messages, maxTokens, signal)
    : streamOpenAI(cfg, model, system, messages, maxTokens, signal);
}

// دمج الرسائل المتتالية من نفس الدور وضمان البدء برسالة مستخدم
function buildMessages(history: Msg[], content: string): Msg[] {
  const out: Msg[] = [];
  for (const m of [...history, { role: "user" as const, content }]) {
    const role = m.role === "assistant" ? "assistant" : "user";
    const last = out[out.length - 1];
    if (last && last.role === role) last.content += "\n\n" + m.content;
    else out.push({ role, content: m.content });
  }
  while (out.length && out[0].role !== "user") out.shift();
  return out;
}

// ---------- اختبار الاتصال (للمالك فقط) ----------

async function handleTest(userId: string): Promise<Response> {
  const { data: pr } = await admin.from("profiles").select("role").eq("id", userId).maybeSingle();
  if (pr?.role !== "admin") return json({ error: "forbidden" }, 403);
  const cfg = aiConfig();
  const info = { provider: cfg.provider, model: cfg.model, smart_model: cfg.smart, base: cfg.base, key_set: !!cfg.key };
  if (!cfg.key) return json({ ok: false, error: "ai_not_configured", ...info });
  try {
    let out = "";
    const gen = streamAI(cfg, cfg.model, "You are a connectivity test.",
      [{ role: "user", content: "Reply with exactly: OK" }], 16, AbortSignal.timeout(30_000));
    for await (const t of gen) out += t;
    return json({ ok: true, reply: out.trim().slice(0, 40), ...info });
  } catch (e) {
    const err = e as AIError;
    return json({ ok: false, error: err.code ?? "ai_error", detail: err.detail ?? String(e), ...info });
  }
}

// ---------- المعالج الرئيسي ----------

async function handle(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  if (!SUPABASE_URL || !SERVICE_KEY) return json({ error: "server_not_configured" }, 500);

  // 1) هوية المستخدم
  const jwt = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "").trim();
  if (!jwt) return json({ error: "unauthorized" }, 401);
  const { data: auth, error: authErr } = await admin.auth.getUser(jwt);
  if (authErr || !auth?.user) return json({ error: "unauthorized" }, 401);
  const userId = auth.user.id;

  let body: any;
  try { body = await req.json(); } catch { return json({ error: "bad_request" }, 400); }

  if (body?.test === true) return await handleTest(userId);

  // 2) التحقق من المدخلات
  const conversationId = String(body?.conversation_id ?? "");
  const content = typeof body?.content === "string" ? body.content : "";
  const mode = String(body?.mode ?? "").slice(0, 40);
  const thinking = String(body?.thinking ?? "").slice(0, 40);
  const lang = LANG_NAME[String(body?.lang)] ? String(body.lang) : "ar";
  if (!UUID_RE.test(conversationId)) return json({ error: "bad_request" }, 400);

  const cfg = aiConfig();
  if (!cfg.key) return json({ error: "ai_not_configured" }, 503);

  // 3) الصلاحيات والحدود (قاعدة البيانات هي المرجع)
  const { data: prep, error: prepErr } = await admin.rpc("chat_prepare", {
    p_user: userId, p_conversation: conversationId, p_content: content, p_mode: mode, p_thinking: thinking,
  });
  if (prepErr || !prep) {
    console.error("chat_prepare failed", prepErr);
    return json({ error: "server_error" }, 500);
  }
  if (!prep.ok) {
    const { ok: _ok, error, ...rest } = prep;
    return json({ error, ...rest }, ERROR_STATUS[error] ?? 400);
  }

  const system = [
    prep.system_base,
    prep.mode_prompt,
    prep.thinking_prompt,
    `لغة واجهة المستخدم: ${LANG_NAME[lang]}. أجب بلغة المستخدم، وإن لم تتضح فاستخدم هذه اللغة.`,
  ].filter(Boolean).join("\n\n");
  const messages = buildMessages((prep.history ?? []) as Msg[], content);
  const model = prep.model_tier === "smart" ? cfg.smart : cfg.model;

  // 4) البثّ
  const enc = new TextEncoder();
  const aborter = new AbortController();
  let aborted = false;
  let ctrl!: ReadableStreamDefaultController<Uint8Array>;
  const stream = new ReadableStream<Uint8Array>({
    start(c) { ctrl = c; },
    cancel() { aborted = true; aborter.abort(); },
  });
  const send = (o: unknown) => {
    try { ctrl.enqueue(enc.encode(`data: ${JSON.stringify(o)}\n\n`)); } catch { /* العميل أغلق الاتصال */ }
  };

  const work = (async () => {
    let full = "";
    const save = (text: string) =>
      admin.rpc("chat_finish", {
        p_user: userId, p_conversation: conversationId, p_user_content: content,
        p_assistant_content: text, p_mode: prep.mode_id ?? null, p_thinking: prep.thinking_id ?? null,
      });
    try {
      const timeout = AbortSignal.timeout(110_000);
      const signal: AbortSignal = typeof (AbortSignal as any).any === "function"
        ? (AbortSignal as any).any([aborter.signal, timeout])
        : aborter.signal;
      for await (const t of streamAI(cfg, model, system, messages, prep.max_tokens, signal)) {
        full += t;
        send({ t });
      }
      if (!full.trim()) throw new AIError("ai_empty", 502, "empty response");
      const { error } = await save(full);
      if (error) console.error("chat_finish failed", error);
      send({ done: true });
    } catch (e) {
      const err = e as AIError;
      const code = aborted ? "aborted" : (err.code ?? "ai_error");
      if (!aborted) console.error("AI call failed:", code, err.status, err.detail ?? String(e));
      if (full.trim()) {
        // وصل جزء من الرد: نحفظه ولا نعيد الرسالة
        const { error } = await save(full);
        if (error) console.error("chat_finish (partial) failed", error);
      } else {
        await admin.rpc("chat_refund", { p_user: userId, p_charged: prep.charged });
      }
      if (!aborted) send({ error: code, partial: !!full.trim() });
    } finally {
      try { ctrl.close(); } catch { /* مغلق */ }
    }
  })();
  // يمنع بيئة Supabase من إيقاف الدالة قبل حفظ الرد عند انقطاع العميل
  (globalThis as any).EdgeRuntime?.waitUntil?.(work);

  return new Response(stream, {
    headers: {
      ...CORS,
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      "X-Accel-Buffering": "no",
    },
  });
}

Deno.serve(async (req) => {
  try {
    return await handle(req);
  } catch (e) {
    console.error("unhandled", e);
    return json({ error: "server_error" }, 500);
  }
});
