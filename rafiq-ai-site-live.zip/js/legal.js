// نصوص «الشروط والأحكام» و«سياسة الخصوصية» الافتراضية بأربع لغات — إعداد وتصميم / فهد مبارك
//
// هذه نصوص جاهزة يمكنك استبدالها بنصك الخاص من لوحة التحكم ← الإعدادات (لكل لغة على حدة).
// راجعها قبل الإطلاق، فهي نموذج عام وليست استشارة قانونية.
// الرمز {site} يُستبدل باسم الموقع. والسطر الذي يبدأ بـ «• » يظهر كعنصر في قائمة.

export const LEGAL_DATE = '2026-11-09';

export const LEGAL = {
  // ======================================================================== الشروط والأحكام
  terms: {
    ar: {
      title: 'الشروط والأحكام',
      sections: [
        ['التعريف بالخدمة', [
          '{site} خدمة مساعد ذكاء اصطناعي عبر الويب، تتيح لك المحادثة بأنماط وأنظمة تفكير مختلفة.',
          'باستخدامك الموقع أو إنشائك حساباً فإنك تقرّ بأنك قرأت هذه الشروط وتوافق عليها. وإن لم توافق فلا تستخدم الخدمة.',
        ]],
        ['الحساب', [
          'يجب أن تكون بالغاً أو تستخدم الخدمة بإشراف وليّ أمرك.',
          'أنت مسؤول عن صحة بياناتك، وعن سرّية كلمة المرور، وعن كل نشاط يتم من حسابك. ولا يجوز مشاركة الحساب مع الآخرين أو بيعه.',
        ]],
        ['الاشتراك والدفع', [
          '• الأسعار بالريال السعودي وتظهر لك في صفحة الباقات وقبل إرسال طلبك.',
          '• الاشتراك سنوي ولا يتجدد تلقائياً. ولا نخصم منك أي مبلغ دون طلبك.',
          '• يتم الدفع بالتحويل البنكي أو STC Pay أو الوسيلة المعلنة في صفحة الاشتراك. ويُفعَّل اشتراكك بعد أن يتحقق صاحب الموقع من وصول المبلغ.',
          '• التجربة المجانية محدودة بعدد الرسائل المعلن عند التسجيل.',
          '• لكل باقة حدّ يومي للرسائل، ومستوى من الأنماط وأنظمة التفكير، كما هو معلن في الباقة.',
        ]],
        ['العروض والكوبونات', [
          'لا تجتمع الخصومات؛ يُطبَّق الأفضل لك منها. وللعروض والكوبونات فترة صلاحية وحدّ استخدام، وقد تنتهي دون إشعار مسبق.',
        ]],
        ['الاسترجاع', [
          'الاشتراك خدمة رقمية تُفعَّل فور اعتماد الدفع. لذلك لا يُسترد مبلغه بعد التفعيل، إلا في الحالات التي يوجبها النظام المعمول به أو يقرّها صاحب الموقع عند تواصلك معه.',
        ]],
        ['الاستخدام المقبول', [
          'لا تستخدم الخدمة في أي نشاط مخالف للنظام، أو لإيذاء الآخرين، أو لانتهاك حقوقهم، أو لنشر محتوى مضلل بقصد الإضرار.',
          'ولا تحاول اختراق الموقع، أو تجاوز حدود الاستخدام، أو استخراج التعليمات الداخلية للأنماط، أو الإفراط في الطلبات الآلية. ويحق لنا إيقاف الحساب عند المخالفة.',
        ]],
        ['طبيعة الإجابات', [
          'الذكاء الاصطناعي قد يخطئ. الإجابات معلومات عامة وليست استشارة طبية أو قانونية أو مالية أو مهنية، وعليك التحقق منها قبل الاعتماد عليها. ولا نتحمل مسؤولية قرار تتخذه بناءً عليها.',
        ]],
        ['المحتوى والملكية', [
          'تبقى نصوصك التي تكتبها ملكاً لك. وتمنحنا ترخيصاً محدوداً لمعالجتها وتخزينها وإرسالها لمزوّد الذكاء الاصطناعي لغرض تقديم الخدمة لك فقط.',
          'تصميم الموقع وبرمجته وشعاره وتعليمات الأنماط محفوظة لأصحابها.',
        ]],
        ['توفّر الخدمة وحدود المسؤولية', [
          'نبذل جهدنا لاستمرار الخدمة، لكنها تُقدَّم «كما هي»، وقد تتوقف أو تتأخر لأسباب خارجة عن إرادتنا مثل انقطاع مزوّد الذكاء الاصطناعي أو الصيانة. وفي حدود ما يسمح به النظام لا تتجاوز مسؤوليتنا قيمة الاشتراك الذي دفعته عن المدة المتأثرة.',
        ]],
        ['التعديل والإنهاء', [
          'قد نعدّل هذه الشروط، وتسري التعديلات بنشرها في هذه الصفحة مع تاريخ التحديث. ولك التوقف عن استخدام الخدمة في أي وقت.',
        ]],
        ['النظام الواجب التطبيق', [
          'تخضع هذه الشروط للأنظمة المعمول بها في المملكة العربية السعودية.',
        ]],
      ],
    },
    en: {
      title: 'Terms of Service',
      sections: [
        ['About the service', [
          '{site} is a web-based AI assistant that lets you chat using different modes and thinking systems.',
          'By using the site or creating an account you confirm that you have read and accept these terms. If you do not accept them, please do not use the service.',
        ]],
        ['Your account', [
          'You must be an adult, or use the service under the supervision of a parent or guardian.',
          'You are responsible for the accuracy of your details, for keeping your password secret, and for everything done through your account. Accounts may not be shared or sold.',
        ]],
        ['Subscription and payment', [
          '• Prices are in Saudi riyals and are shown on the plans page and before you submit your request.',
          '• A subscription lasts one year and does not renew automatically. We never charge you without your request.',
          '• Payment is made by bank transfer, STC Pay or the method shown on the checkout page. Your subscription is activated after the site owner confirms the payment has arrived.',
          '• The free trial is limited to the number of messages shown when you sign up.',
          '• Each plan has a daily message limit and a level of modes and thinking systems, as stated in the plan.',
        ]],
        ['Offers and coupons', [
          'Discounts cannot be combined; the best one for you is applied. Offers and coupons have a validity period and a usage limit, and may end without prior notice.',
        ]],
        ['Refunds', [
          'A subscription is a digital service activated as soon as payment is approved. It is therefore non-refundable after activation, except where the applicable law requires otherwise or the site owner agrees when you contact them.',
        ]],
        ['Acceptable use', [
          'Do not use the service for anything unlawful, to harm others or violate their rights, or to spread misleading content intended to cause harm.',
          'Do not try to break into the site, bypass usage limits, extract the internal instructions of the modes, or send excessive automated requests. We may suspend an account that breaks these rules.',
        ]],
        ['Nature of the answers', [
          'AI can make mistakes. Answers are general information, not medical, legal, financial or professional advice, and you should verify them before relying on them. We are not responsible for decisions you make based on them.',
        ]],
        ['Content and ownership', [
          'The text you write remains yours. You give us a limited licence to process it, store it and send it to the AI provider solely to provide the service to you.',
          'The design, code, logo and mode instructions of the site belong to their owners.',
        ]],
        ['Availability and liability', [
          'We work to keep the service running, but it is provided "as is" and may stop or slow down for reasons beyond our control, such as an AI provider outage or maintenance. To the extent the law allows, our liability does not exceed the subscription fee you paid for the affected period.',
        ]],
        ['Changes and ending', [
          'We may change these terms; changes take effect when published on this page with the new update date. You may stop using the service at any time.',
        ]],
        ['Governing law', [
          'These terms are governed by the laws in force in the Kingdom of Saudi Arabia.',
        ]],
      ],
    },
    fr: {
      title: 'Conditions d’utilisation',
      sections: [
        ['Le service', [
          '{site} est un assistant d’intelligence artificielle en ligne qui vous permet de discuter avec différents modes et systèmes de réflexion.',
          'En utilisant le site ou en créant un compte, vous confirmez avoir lu et accepté ces conditions. Si vous ne les acceptez pas, n’utilisez pas le service.',
        ]],
        ['Votre compte', [
          'Vous devez être majeur, ou utiliser le service sous la supervision d’un parent ou d’un tuteur.',
          'Vous êtes responsable de l’exactitude de vos informations, de la confidentialité de votre mot de passe et de toute activité réalisée depuis votre compte. Un compte ne peut être ni partagé ni vendu.',
        ]],
        ['Abonnement et paiement', [
          '• Les prix sont en riyals saoudiens et s’affichent sur la page des offres avant l’envoi de votre demande.',
          '• L’abonnement dure un an et ne se renouvelle pas automatiquement. Nous ne prélevons jamais rien sans votre demande.',
          '• Le paiement se fait par virement bancaire, STC Pay ou le moyen indiqué lors de la souscription. L’abonnement est activé après vérification de la réception du paiement par le propriétaire du site.',
          '• L’essai gratuit est limité au nombre de messages indiqué à l’inscription.',
          '• Chaque offre comporte une limite quotidienne de messages et un niveau de modes et de systèmes de réflexion, tels qu’indiqués dans l’offre.',
        ]],
        ['Offres et coupons', [
          'Les réductions ne se cumulent pas : la plus avantageuse pour vous est appliquée. Les offres et coupons ont une durée de validité et une limite d’utilisation, et peuvent prendre fin sans préavis.',
        ]],
        ['Remboursement', [
          'L’abonnement est un service numérique activé dès l’approbation du paiement. Il n’est donc pas remboursable après activation, sauf si la loi applicable l’exige ou si le propriétaire du site l’accepte lorsque vous le contactez.',
        ]],
        ['Utilisation acceptable', [
          'N’utilisez pas le service pour une activité illégale, pour nuire à autrui ou porter atteinte à ses droits, ni pour diffuser des contenus trompeurs destinés à nuire.',
          'N’essayez pas de pirater le site, de contourner les limites d’utilisation, d’extraire les instructions internes des modes ni d’envoyer des requêtes automatisées excessives. Nous pouvons suspendre un compte en cas de manquement.',
        ]],
        ['Nature des réponses', [
          'L’IA peut se tromper. Les réponses sont des informations générales et non des conseils médicaux, juridiques, financiers ou professionnels ; vérifiez-les avant de vous y fier. Nous ne sommes pas responsables des décisions prises sur cette base.',
        ]],
        ['Contenu et propriété', [
          'Les textes que vous écrivez restent les vôtres. Vous nous accordez une licence limitée pour les traiter, les stocker et les transmettre au fournisseur d’IA, uniquement pour vous fournir le service.',
          'La conception, le code, le logo et les instructions des modes du site appartiennent à leurs titulaires.',
        ]],
        ['Disponibilité et responsabilité', [
          'Nous faisons notre possible pour maintenir le service, mais il est fourni « en l’état » et peut s’interrompre ou ralentir pour des raisons indépendantes de notre volonté, comme une panne du fournisseur d’IA ou une maintenance. Dans la mesure permise par la loi, notre responsabilité ne dépasse pas le prix de l’abonnement payé pour la période concernée.',
        ]],
        ['Modifications et fin', [
          'Nous pouvons modifier ces conditions ; les modifications prennent effet dès leur publication sur cette page avec la nouvelle date. Vous pouvez cesser d’utiliser le service à tout moment.',
        ]],
        ['Droit applicable', [
          'Ces conditions sont régies par les lois en vigueur au Royaume d’Arabie saoudite.',
        ]],
      ],
    },
    ur: {
      title: 'شرائط و ضوابط',
      sections: [
        ['سروس کا تعارف', [
          '{site} ویب پر مصنوعی ذہانت کا ایک معاون ہے جس سے آپ مختلف انداز اور طرزِ فکر کے ساتھ گفتگو کر سکتے ہیں۔',
          'سائٹ استعمال کرنے یا اکاؤنٹ بنانے کا مطلب ہے کہ آپ نے ان شرائط کو پڑھ کر قبول کر لیا ہے۔ اگر آپ متفق نہیں ہیں تو سروس استعمال نہ کریں۔',
        ]],
        ['آپ کا اکاؤنٹ', [
          'آپ کا بالغ ہونا ضروری ہے، یا سرپرست کی نگرانی میں سروس استعمال کریں۔',
          'اپنی معلومات کی درستی، پاس ورڈ کی رازداری اور اپنے اکاؤنٹ سے ہونے والی ہر سرگرمی کے آپ خود ذمہ دار ہیں۔ اکاؤنٹ کسی اور کو دینا یا بیچنا جائز نہیں۔',
        ]],
        ['سبسکرپشن اور ادائیگی', [
          '• قیمتیں سعودی ریال میں ہیں اور پیکجز کے صفحے پر درخواست بھیجنے سے پہلے دکھائی جاتی ہیں۔',
          '• سبسکرپشن ایک سال کی ہوتی ہے اور خود بخود تجدید نہیں ہوتی۔ آپ کی درخواست کے بغیر ہم کوئی رقم نہیں کاٹتے۔',
          '• ادائیگی بینک ٹرانسفر، STC Pay یا سبسکرپشن کے صفحے پر بتائے گئے طریقے سے ہوتی ہے۔ سائٹ کا مالک رقم موصول ہونے کی تصدیق کر لے تو سبسکرپشن فعال ہوتی ہے۔',
          '• مفت آزمائش رجسٹریشن کے وقت بتائے گئے پیغامات کی تعداد تک محدود ہے۔',
          '• ہر پیکج کی روزانہ پیغامات کی حد اور انداز و طرزِ فکر کی سطح پیکج میں بتائی گئی ہوتی ہے۔',
        ]],
        ['آفرز اور کوپن', [
          'رعایتیں آپس میں جمع نہیں ہوتیں؛ آپ کے لیے سب سے بہتر لاگو ہوتی ہے۔ آفرز اور کوپن کی مدت اور استعمال کی حد ہوتی ہے اور وہ بغیر اطلاع ختم ہو سکتے ہیں۔',
        ]],
        ['رقم کی واپسی', [
          'سبسکرپشن ایک ڈیجیٹل سروس ہے جو ادائیگی منظور ہوتے ہی فعال ہو جاتی ہے۔ اس لیے فعال ہونے کے بعد رقم واپس نہیں ہوتی، سوائے اس کے کہ نافذ قانون اس کا تقاضا کرے یا رابطہ کرنے پر سائٹ کا مالک منظور کرے۔',
        ]],
        ['جائز استعمال', [
          'سروس کو کسی غیر قانونی کام، دوسروں کو نقصان پہنچانے یا ان کے حقوق کی خلاف ورزی، یا نقصان کی نیت سے گمراہ کن مواد پھیلانے کے لیے استعمال نہ کریں۔',
          'سائٹ میں نقب لگانے، استعمال کی حدیں توڑنے، انداز کی اندرونی ہدایات نکالنے یا حد سے زیادہ خودکار درخواستیں بھیجنے کی کوشش نہ کریں۔ خلاف ورزی پر ہم اکاؤنٹ معطل کر سکتے ہیں۔',
        ]],
        ['جوابات کی نوعیت', [
          'مصنوعی ذہانت غلطی کر سکتی ہے۔ جوابات عمومی معلومات ہیں، طبی، قانونی، مالی یا پیشہ ورانہ مشورہ نہیں، اور ان پر بھروسا کرنے سے پہلے آپ کو تصدیق کرنی چاہیے۔ ان کی بنیاد پر کیے گئے کسی فیصلے کے ہم ذمہ دار نہیں۔',
        ]],
        ['مواد اور ملکیت', [
          'آپ کا لکھا ہوا متن آپ ہی کی ملکیت رہتا ہے۔ آپ ہمیں محدود اجازت دیتے ہیں کہ ہم اسے صرف آپ کو سروس دینے کے لیے پروسیس کریں، محفوظ کریں اور مصنوعی ذہانت فراہم کنندہ کو بھیجیں۔',
          'سائٹ کا ڈیزائن، کوڈ، لوگو اور انداز کی ہدایات اپنے مالکان کی ملکیت ہیں۔',
        ]],
        ['دستیابی اور ذمہ داری', [
          'ہم سروس جاری رکھنے کی پوری کوشش کرتے ہیں، مگر یہ «جیسی ہے» کی بنیاد پر دی جاتی ہے اور ہمارے قابو سے باہر وجوہات، مثلاً فراہم کنندہ میں خرابی یا مرمت، سے رک یا سست ہو سکتی ہے۔ قانون جہاں تک اجازت دے، ہماری ذمہ داری متاثرہ مدت کی ادا کی گئی سبسکرپشن فیس سے زیادہ نہیں۔',
        ]],
        ['تبدیلی اور اختتام', [
          'ہم ان شرائط میں تبدیلی کر سکتے ہیں، اور تبدیلی نئی تاریخ کے ساتھ اس صفحے پر شائع ہوتے ہی نافذ ہو جاتی ہے۔ آپ جب چاہیں سروس کا استعمال بند کر سکتے ہیں۔',
        ]],
        ['نافذ قانون', [
          'ان شرائط پر مملکت سعودی عرب میں نافذ قوانین لاگو ہوتے ہیں۔',
        ]],
      ],
    },
  },

  // ======================================================================== سياسة الخصوصية
  privacy: {
    ar: {
      title: 'سياسة الخصوصية',
      sections: [
        ['ما الذي نجمعه', [
          '• بيانات الحساب: الاسم والبريد الإلكتروني وكلمة المرور (تُخزَّن مشفّرة ولا يمكننا قراءتها).',
          '• المحادثات: الرسائل التي تكتبها وردود الذكاء الاصطناعي عليها.',
          '• بيانات الاشتراك: الباقة والمدة وطلبات الدفع (رقم العملية وملاحظتك). ولا نجمع بيانات بطاقاتك المصرفية.',
          '• بيانات الاستخدام: عدد رسائلك اليومية، ولغتك ومظهرك المفضّل.',
        ]],
        ['لماذا نستخدمها', [
          'لتشغيل حسابك، وتوليد الردود، وتطبيق حدود الاشتراك، ومراجعة المدفوعات، وحماية الموقع من إساءة الاستخدام، والتواصل معك بشأن حسابك.',
        ]],
        ['مع من نشاركها', [
          'لا نبيع بياناتك. تُعالَج لدى مزوّدي الخدمة الذين نعتمد عليهم: مزوّد قاعدة البيانات وتسجيل الدخول (Supabase)، ومزوّد الاستضافة، ومزوّد الذكاء الاصطناعي الذي يستقبل نص محادثتك ليولّد الرد.',
          'وقد نفصح عن بيانات محددة إذا ألزمنا النظام بذلك.',
        ]],
        ['مدة الحفظ وحذف البيانات', [
          'نحتفظ بمحادثاتك حتى تحذفها أنت أو يُحذف حسابك. يمكنك حذف محادثاتك وتصدير بياناتك من صفحة «حسابي». ولحذف الحساب كاملاً تواصل معنا. ونحتفظ بسجلات الدفع المدة التي يتطلبها النظام.',
        ]],
        ['الأمان', [
          'تُخزَّن بياناتك في قاعدة بيانات محمية بسياسات وصول تمنع أي مستخدم من قراءة بيانات غيره، والاتصال بالموقع مشفّر (HTTPS). ومع ذلك لا يوجد نظام آمن بنسبة كاملة، فلا ترسل في المحادثة معلومات شديدة الحساسية مثل كلمات المرور وأرقام البطاقات والهويات.',
        ]],
        ['حقوقك', [
          'يحق لك طلب الاطلاع على بياناتك أو تصحيحها أو تصديرها أو حذفها، وسحب موافقتك، وذلك بالتواصل معنا.',
        ]],
        ['التخزين في المتصفح', [
          'نستخدم التخزين المحلي في متصفحك لحفظ جلسة دخولك ولغتك ومظهرك فقط. ولا نستخدم إعلانات ولا أدوات تتبع.',
        ]],
        ['الأطفال', [
          'الخدمة غير موجّهة للأطفال. إن علمت أن طفلك أنشأ حساباً فتواصل معنا ليُحذف.',
        ]],
        ['التغييرات', [
          'قد نحدّث هذه السياسة، وننشر النسخة الجديدة مع تاريخ التحديث في أعلى هذه الصفحة.',
        ]],
      ],
    },
    en: {
      title: 'Privacy Policy',
      sections: [
        ['What we collect', [
          '• Account details: your name, email address and password (stored encrypted; we cannot read it).',
          '• Conversations: the messages you write and the AI replies to them.',
          '• Subscription details: your plan, its period and payment requests (transfer reference and your note). We do not collect your bank card details.',
          '• Usage details: your daily message count, and your preferred language and theme.',
        ]],
        ['Why we use it', [
          'To run your account, generate replies, apply subscription limits, review payments, protect the site from abuse, and contact you about your account.',
        ]],
        ['Who we share it with', [
          'We do not sell your data. It is processed by the service providers we rely on: the database and sign-in provider (Supabase), the hosting provider, and the AI provider, which receives the text of your conversation in order to generate the reply.',
          'We may disclose specific data if the law requires us to.',
        ]],
        ['Retention and deletion', [
          'We keep your conversations until you delete them or your account is deleted. You can delete your conversations and export your data from the Account page. To delete the whole account, contact us. Payment records are kept for as long as the law requires.',
        ]],
        ['Security', [
          'Your data is stored in a database protected by access policies that stop any user from reading another user’s data, and the connection to the site is encrypted (HTTPS). Still, no system is perfectly secure, so do not send highly sensitive information such as passwords, card numbers or ID documents in the chat.',
        ]],
        ['Your rights', [
          'You may ask to access, correct, export or delete your data, and to withdraw your consent, by contacting us.',
        ]],
        ['Browser storage', [
          'We use your browser’s local storage only to keep your sign-in session, language and theme. We use no advertising and no tracking tools.',
        ]],
        ['Children', [
          'The service is not aimed at children. If you learn that your child has created an account, contact us and we will delete it.',
        ]],
        ['Changes', [
          'We may update this policy and will publish the new version with its update date at the top of this page.',
        ]],
      ],
    },
    fr: {
      title: 'Politique de confidentialité',
      sections: [
        ['Ce que nous collectons', [
          '• Données de compte : votre nom, votre adresse e-mail et votre mot de passe (stocké chiffré ; nous ne pouvons pas le lire).',
          '• Conversations : les messages que vous écrivez et les réponses de l’IA.',
          '• Données d’abonnement : votre offre, sa durée et vos demandes de paiement (référence du virement et votre note). Nous ne collectons pas vos données de carte bancaire.',
          '• Données d’usage : votre nombre de messages quotidiens, ainsi que votre langue et votre thème préférés.',
        ]],
        ['Pourquoi nous les utilisons', [
          'Pour faire fonctionner votre compte, générer les réponses, appliquer les limites de l’abonnement, vérifier les paiements, protéger le site contre les abus et vous contacter au sujet de votre compte.',
        ]],
        ['Avec qui nous les partageons', [
          'Nous ne vendons pas vos données. Elles sont traitées par les prestataires dont nous dépendons : le fournisseur de base de données et de connexion (Supabase), l’hébergeur, et le fournisseur d’IA qui reçoit le texte de votre conversation pour générer la réponse.',
          'Nous pouvons divulguer certaines données si la loi nous y oblige.',
        ]],
        ['Conservation et suppression', [
          'Nous conservons vos conversations jusqu’à ce que vous les supprimiez ou que votre compte soit supprimé. Vous pouvez supprimer vos conversations et exporter vos données depuis la page Compte. Pour supprimer tout le compte, contactez-nous. Les justificatifs de paiement sont conservés aussi longtemps que la loi l’exige.',
        ]],
        ['Sécurité', [
          'Vos données sont stockées dans une base protégée par des règles d’accès qui empêchent tout utilisateur de lire celles d’un autre, et la connexion au site est chiffrée (HTTPS). Aucun système n’étant parfaitement sûr, n’envoyez pas d’informations très sensibles (mots de passe, numéros de carte, pièces d’identité) dans la conversation.',
        ]],
        ['Vos droits', [
          'Vous pouvez demander l’accès à vos données, leur rectification, leur export ou leur suppression, et retirer votre consentement, en nous contactant.',
        ]],
        ['Stockage dans le navigateur', [
          'Nous utilisons le stockage local de votre navigateur uniquement pour conserver votre session, votre langue et votre thème. Nous n’utilisons ni publicité ni outil de suivi.',
        ]],
        ['Enfants', [
          'Le service ne s’adresse pas aux enfants. Si vous apprenez que votre enfant a créé un compte, contactez-nous et nous le supprimerons.',
        ]],
        ['Modifications', [
          'Nous pouvons mettre à jour cette politique et publierons la nouvelle version avec sa date en haut de cette page.',
        ]],
      ],
    },
    ur: {
      title: 'پرائیویسی پالیسی',
      sections: [
        ['ہم کیا جمع کرتے ہیں', [
          '• اکاؤنٹ کی معلومات: آپ کا نام، ای میل اور پاس ورڈ (پاس ورڈ خفیہ شکل میں محفوظ ہوتا ہے اور ہم اسے پڑھ نہیں سکتے)۔',
          '• گفتگو: آپ کے لکھے ہوئے پیغامات اور ان پر مصنوعی ذہانت کے جوابات۔',
          '• سبسکرپشن کی معلومات: پیکج، مدت اور ادائیگی کی درخواستیں (ٹرانسفر کا حوالہ نمبر اور آپ کا نوٹ)۔ ہم آپ کے بینک کارڈ کی معلومات جمع نہیں کرتے۔',
          '• استعمال کی معلومات: روزانہ پیغامات کی تعداد، اور آپ کی پسندیدہ زبان اور تھیم۔',
        ]],
        ['ہم انہیں کیوں استعمال کرتے ہیں', [
          'آپ کا اکاؤنٹ چلانے، جوابات تیار کرنے، سبسکرپشن کی حدیں نافذ کرنے، ادائیگیاں جانچنے، سائٹ کو غلط استعمال سے بچانے اور آپ کے اکاؤنٹ کے بارے میں رابطہ کرنے کے لیے۔',
        ]],
        ['ہم کس کے ساتھ شیئر کرتے ہیں', [
          'ہم آپ کا ڈیٹا فروخت نہیں کرتے۔ اس پر وہ خدمت فراہم کنندگان کارروائی کرتے ہیں جن پر ہم انحصار کرتے ہیں: ڈیٹا بیس اور لاگ اِن فراہم کنندہ (Supabase)، ہوسٹنگ فراہم کنندہ، اور مصنوعی ذہانت فراہم کنندہ جو جواب تیار کرنے کے لیے آپ کی گفتگو کا متن وصول کرتا ہے۔',
          'قانون کا تقاضا ہو تو ہم مخصوص ڈیٹا ظاہر کر سکتے ہیں۔',
        ]],
        ['محفوظ رکھنے کی مدت اور حذف', [
          'ہم آپ کی گفتگو اس وقت تک رکھتے ہیں جب تک آپ اسے حذف نہ کریں یا اکاؤنٹ حذف نہ ہو جائے۔ آپ «میرا اکاؤنٹ» کے صفحے سے اپنی گفتگو حذف اور ڈیٹا ایکسپورٹ کر سکتے ہیں۔ پورا اکاؤنٹ حذف کرانے کے لیے ہم سے رابطہ کریں۔ ادائیگی کے ریکارڈ اتنی مدت رکھے جاتے ہیں جتنی قانون کا تقاضا ہو۔',
        ]],
        ['سلامتی', [
          'آپ کا ڈیٹا ایسے ڈیٹا بیس میں رہتا ہے جو رسائی کے اصولوں سے محفوظ ہے اور کسی صارف کو دوسرے کا ڈیٹا پڑھنے نہیں دیتا، اور سائٹ سے رابطہ خفیہ (HTTPS) ہے۔ پھر بھی کوئی نظام مکمل محفوظ نہیں ہوتا، اس لیے گفتگو میں پاس ورڈ، کارڈ نمبر اور شناختی دستاویزات جیسی انتہائی حساس معلومات نہ بھیجیں۔',
        ]],
        ['آپ کے حقوق', [
          'آپ ہم سے رابطہ کر کے اپنا ڈیٹا دیکھنے، درست کرانے، ایکسپورٹ کرنے یا حذف کرانے اور اپنی رضامندی واپس لینے کی درخواست کر سکتے ہیں۔',
        ]],
        ['براؤزر میں محفوظ معلومات', [
          'ہم آپ کے براؤزر کی لوکل اسٹوریج صرف لاگ اِن سیشن، زبان اور تھیم محفوظ رکھنے کے لیے استعمال کرتے ہیں۔ ہم اشتہارات یا ٹریکنگ کے آلات استعمال نہیں کرتے۔',
        ]],
        ['بچے', [
          'یہ سروس بچوں کے لیے نہیں ہے۔ اگر آپ کو معلوم ہو کہ آپ کے بچے نے اکاؤنٹ بنایا ہے تو ہم سے رابطہ کریں، ہم اسے حذف کر دیں گے۔',
        ]],
        ['تبدیلیاں', [
          'ہم اس پالیسی کو اپ ڈیٹ کر سکتے ہیں اور نیا ورژن اپ ڈیٹ کی تاریخ کے ساتھ اس صفحے کے اوپر شائع کریں گے۔',
        ]],
      ],
    },
  },
};
