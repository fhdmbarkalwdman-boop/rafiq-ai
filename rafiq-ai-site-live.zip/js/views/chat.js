// صفحة المحادثة مع الذكاء الاصطناعي — إعداد وتصميم / فهد مبارك
import { h, icon, toast, openModal, confirmDialog, copyText, spinner } from '../ui.js';
import { t, tr, trList, getLang, fmt } from '../i18n.js';
import * as api from '../api.js';
import { renderMarkdown } from '../markdown.js';
import { S, isAdmin, userTier, refreshStatus, planForTier, setting } from '../state.js';

const allowed = item => item.min_tier <= userTier();
function pickDefault(list, preferred) {
  const ok = list.filter(allowed);
  return (preferred && ok.find(x => x.id === preferred)) || ok[0] || list[0] || null;
}
const blocked = () => { const s = S.status || {}; return !isAdmin() && !s.plan && (s.trial_left ?? 0) <= 0; };
const limitReached = () => { const s = S.status || {}; return !!s.plan && s.used_today >= s.plan.daily_limit; };

function dots() { return h('span', { class: 'dots', 'aria-label': '…' }, h('i'), h('i'), h('i')); }
function setMd(el, text) {
  el.innerHTML = renderMarkdown(text);
  el.querySelectorAll('.code-copy').forEach(b => { b.textContent = t('common.copy'); });
}

export async function chatView(ctx) {
  const st = { convs: [], cur: null, msgs: [], mode: null, thinking: null, busy: false, ctrl: null, side: false };
  st.mode = pickDefault(S.catalog.modes, S.profile?.default_mode);
  st.thinking = pickDefault(S.catalog.thinking, S.profile?.default_thinking || 'balanced');
  const maxChars = Number(setting('max_input_chars', 4000)) || 4000;

  const root = h('div', { class: 'chat' });
  const side = h('aside', { class: 'chat-side', 'aria-label': t('chat.history') });
  const headEl = h('div', { class: 'chat-head' });
  const log = h('div', { class: 'chat-log', role: 'log', 'aria-live': 'polite' });
  const composerBox = h('div', { class: 'composer-box' });
  const main = h('section', { class: 'chat-main' }, headEl, log, composerBox);
  const scrim = h('div', { class: 'side-scrim', onclick: () => toggleSide(false) });
  root.append(side, main, scrim);

  const input = h('textarea', { id: 'chat-input', class: 'composer-input', rows: 1, maxlength: maxChars, placeholder: t('chat.placeholder'), 'aria-label': t('chat.placeholder') });
  const sendBtn = h('button', { class: 'send-btn', type: 'submit', 'aria-label': t('chat.send') }, icon('send', 20));
  const form = h('form', { class: 'composer', autocomplete: 'off' }, input, sendBtn);

  function toggleSide(on) { st.side = on; root.classList.toggle('side-open', on); }
  const grow = () => { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 180) + 'px'; };
  const nearBottom = () => log.scrollHeight - log.scrollTop - log.clientHeight < 140;
  const toBottom = () => { log.scrollTop = log.scrollHeight; };

  // ------------------------------------------------ الشريط الجانبي
  function usageBox() {
    const s = S.status || {};
    if (isAdmin()) return h('div', { class: 'usage' }, h('strong', null, t('chat.owner')), h('span', { class: 'muted small' }, t('chat.unlimited')));
    if (s.plan) {
      const pct = Math.min(100, Math.round((s.used_today / s.plan.daily_limit) * 100));
      return h('div', { class: 'usage' },
        h('div', { class: 'usage-top' }, h('strong', null, tr(s.plan.name)), h('span', { class: 'muted small' }, `${fmt.num(s.used_today)} / ${fmt.num(s.plan.daily_limit)}`)),
        h('div', { class: 'meter', role: 'progressbar', 'aria-valuemin': 0, 'aria-valuemax': s.plan.daily_limit, 'aria-valuenow': s.used_today }, h('i', { style: { width: pct + '%' }, class: pct >= 90 ? 'hot' : '' })),
        h('span', { class: 'muted small' }, t('chat.todayUsage')), h('span', { class: 'muted small' }, t('chat.until', { date: fmt.date(s.plan.ends_at) })));
    }
    return h('div', { class: 'usage' },
      h('strong', null, t('chat.trial')),
      h('span', { class: 'muted small' }, t('chat.trialLeft', { n: fmt.num(s.trial_left ?? 0), total: fmt.num(s.trial_total ?? 0) })),
      h('a', { class: 'btn btn-primary btn-sm btn-block', href: '#/pricing' }, t('account.subscribe')));
  }

  function drawSide() {
    side.replaceChildren(
      h('div', { class: 'side-top' },
        h('button', { class: 'btn btn-primary btn-block', type: 'button', onclick: newChat }, icon('plus', 18), t('chat.new')),
        h('button', { class: 'icon-btn side-close', type: 'button', 'aria-label': t('common.close'), onclick: () => toggleSide(false) }, icon('close', 18))),
      h('div', { class: 'conv-list' }, st.convs.length ? st.convs.map(c => h('div', { class: 'conv' + (st.cur && st.cur.id === c.id ? ' on' : '') },
        h('button', { class: 'conv-open', type: 'button', title: c.title || t('chat.untitled'), onclick: () => openConv(c.id) }, c.title || t('chat.untitled')),
        h('button', { class: 'icon-btn xs', type: 'button', 'aria-label': t('chat.rename'), onclick: () => renameConv(c) }, icon('edit', 14)),
        h('button', { class: 'icon-btn xs', type: 'button', 'aria-label': t('common.delete'), onclick: () => deleteConv(c) }, icon('trash', 14)))) : [h('p', { class: 'muted small pad' }, t('chat.noHistory'))]),
      usageBox(),
      h('p', { class: 'credit sm' }, t('footer.credit')));
  }

  async function renameConv(c) {
    const input = h('input', { id: 'rn', class: 'input', value: c.title, maxlength: 80 });
    const m = openModal({ title: t('chat.rename'), size: 'sm', body: h('form', { onsubmit: async e => { e.preventDefault(); try { await api.renameConversation(c.id, input.value.trim() || c.title); c.title = input.value.trim() || c.title; drawSide(); drawHead(); m.close(); } catch { toast(t('err.generic'), 'bad'); } } }, input, h('button', { class: 'btn btn-primary btn-block spaced', type: 'submit' }, t('common.save'))) });
  }
  async function deleteConv(c) {
    if (!(await confirmDialog(t('chat.deleteConfirm'), { okLabel: t('common.delete'), cancelLabel: t('common.cancel'), danger: true }))) return;
    try {
      await api.deleteConversation(c.id);
      st.convs = st.convs.filter(x => x.id !== c.id);
      if (st.cur && st.cur.id === c.id) newChat(); else drawSide();
    } catch { toast(t('err.generic'), 'bad'); }
  }

  // ------------------------------------------------ الرأس واختيار النمط/التفكير
  function pill(kind, item) {
    return h('button', { class: 'pill', type: 'button', 'data-kind': kind, 'aria-haspopup': 'dialog', onclick: () => openPicker(kind) },
      icon(item?.icon || 'sparkle', 16), h('span', { class: 'pill-label' }, t(kind === 'mode' ? 'chat.mode' : 'chat.thinking')), h('strong', null, item ? tr(item.name) : '-'), icon('chevron', 14));
  }
  function drawHead() {
    headEl.replaceChildren(
      h('button', { class: 'icon-btn chat-menu', type: 'button', 'aria-label': t('chat.history'), onclick: () => toggleSide(true) }, icon('menu', 20)),
      h('h2', { class: 'chat-title' }, st.cur?.title || tr(st.mode.name)),
      h('div', { class: 'pills' }, pill('mode', st.mode), pill('thinking', st.thinking)));
  }
  function openPicker(kind) {
    if (st.busy) return;
    const list = kind === 'mode' ? S.catalog.modes : S.catalog.thinking;
    const cur = kind === 'mode' ? st.mode : st.thinking;
    const m = openModal({ title: t(kind === 'mode' ? 'chat.pickMode' : 'chat.pickThinking'), size: 'md', sheet: true, body: h('div', { class: 'picker' },
      h('p', { class: 'muted small' }, t(kind === 'mode' ? 'chat.pickModeHint' : 'chat.pickThinkingHint')),
      list.map(it => {
        const ok = allowed(it);
        const need = planForTier(it.min_tier);
        return h('button', {
          class: 'pick' + (cur && cur.id === it.id ? ' on' : '') + (ok ? '' : ' locked'), type: 'button', dataset: { id: it.id },
          onclick: () => {
            if (!ok) { m.close(); toast(t('chat.needPlan', { plan: need ? tr(need.name) : '' }), 'info'); ctx.go('pricing'); return; }
            if (kind === 'mode') st.mode = it; else st.thinking = it;
            m.close(); drawHead(); if (!st.msgs.length) drawLog(); input.focus();
          },
        }, h('span', { class: 'tile-ico' }, icon(it.icon, 20)),
          h('span', { class: 'pick-text' }, h('strong', null, tr(it.name)), h('span', { class: 'muted small' }, tr(it.description))),
          ok ? (cur && cur.id === it.id ? icon('check', 18) : null) : h('span', { class: 'chip' }, icon('lock', 12), need ? tr(need.name) : ''));
      })) });
  }

  // ------------------------------------------------ الرسائل
  function errorMessage(code) {
    const key = 'err.' + code;
    const txt = t(key);
    return txt === key ? t('err.ai_error') : txt;
  }
  function msgNode(m, i) {
    if (m.role === 'user') return h('div', { class: 'msg user' }, h('div', { class: 'bubble' }, m.content));
    if (m.role === 'error') {
      const upsell = ['subscription_required', 'daily_limit', 'locked_mode', 'locked_thinking'].includes(m.code);
      const owner = ['ai_not_configured', 'ai_auth', 'function_missing'].includes(m.code) && isAdmin();
      return h('div', { class: 'msg err', role: 'alert' }, icon('shield', 18), h('div', null, h('p', null, errorMessage(m.code)),
        upsell ? h('a', { class: 'btn btn-primary btn-sm', href: '#/pricing' }, t('chat.viewPlans')) : null,
        owner ? h('a', { class: 'btn btn-secondary btn-sm', href: '#/admin' }, t('nav.admin')) : null));
    }
    const bubble = h('div', { class: 'bubble md' });
    if (m.content) setMd(bubble, m.content); else bubble.append(dots());
    const node = h('div', { class: 'msg bot', dataset: { i } }, bubble);
    if (m.content && !m.streaming) node.append(h('div', { class: 'msg-actions' },
      h('button', { class: 'icon-btn xs', type: 'button', 'aria-label': t('common.copy'), title: t('common.copy'), onclick: e => { copyText(m.content); const b = e.currentTarget; b.replaceChildren(icon('check', 14)); setTimeout(() => b.replaceChildren(icon('copy', 14)), 1200); } }, icon('copy', 14))));
    return node;
  }
  function drawLog() {
    log.replaceChildren();
    if (!st.msgs.length) {
      const starters = trList(st.mode.starters);
      log.append(h('div', { class: 'chat-empty' },
        h('span', { class: 'tile-ico lg' }, icon(st.mode.icon, 28)),
        h('h2', null, tr(st.mode.name)), h('p', { class: 'muted' }, tr(st.mode.description)),
        h('div', { class: 'starters' }, starters.map(s => h('button', { class: 'starter', type: 'button', onclick: () => { input.value = s; grow(); input.focus(); } }, s)))));
      return;
    }
    st.msgs.forEach((m, i) => log.append(msgNode(m, i)));
    toBottom();
  }
  log.addEventListener('click', e => {
    const b = e.target.closest('.code-copy'); if (!b) return;
    copyText(b.closest('.code').querySelector('code').textContent);
    const old = b.textContent; b.textContent = t('common.copied'); setTimeout(() => { b.textContent = old; }, 1200);
  });

  // ------------------------------------------------ المحرر
  function drawComposer() {
    composerBox.replaceChildren();
    if (blocked()) {
      composerBox.append(h('div', { class: 'paywall' }, h('span', { class: 'done-ico' }, icon('lock', 24)),
        h('div', null, h('strong', null, t('paywall.title')), h('p', { class: 'muted' }, t('paywall.text'))),
        h('a', { class: 'btn btn-primary', href: '#/pricing' }, t('paywall.cta'))));
      return;
    }
    if (limitReached()) {
      composerBox.append(h('div', { class: 'paywall soft' }, icon('gauge', 22), h('div', null, h('strong', null, t('limit.title')), h('p', { class: 'muted' }, t('limit.text'))),
        h('a', { class: 'btn btn-secondary', href: '#/pricing' }, t('limit.cta'))));
      return;
    }
    composerBox.append(form, h('p', { class: 'composer-hint' }, t('chat.hint')));
  }
  function setBusy(on) {
    st.busy = on;
    sendBtn.replaceChildren(icon(on ? 'stop' : 'send', 20));
    sendBtn.classList.toggle('stop', on);
    sendBtn.setAttribute('aria-label', t(on ? 'chat.stop' : 'chat.send'));
    sendBtn.type = on ? 'button' : 'submit';
    root.classList.toggle('busy', on);
  }
  sendBtn.addEventListener('click', () => { if (st.busy && st.ctrl) st.ctrl.abort(); });
  input.addEventListener('input', grow);
  input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); form.requestSubmit(); } });
  form.addEventListener('submit', e => { e.preventDefault(); if (!st.busy) send(input.value); });

  async function send(raw) {
    const text = raw.trim();
    if (!text || st.busy) return;
    if (blocked() || limitReached()) { drawComposer(); return; }
    setBusy(true);
    let bot;
    try {
      if (!st.cur) {
        const c = await api.createConversation(S.user.id, st.mode.id, st.thinking.id);
        st.cur = c; st.convs.unshift(c);
        history.replaceState(null, '', '#/chat/' + c.id);
        drawSide(); drawHead();
      }
      input.value = ''; grow();
      st.msgs.push({ role: 'user', content: text });
      bot = { role: 'assistant', content: '', streaming: true };
      st.msgs.push(bot);
      drawLog();
      const botEl = () => log.lastElementChild?.querySelector('.bubble');
      st.ctrl = new AbortController();
      let raf = 0;
      await api.streamChat({
        conversationId: st.cur.id, content: text, mode: st.mode.id, thinking: st.thinking.id, lang: getLang(), signal: st.ctrl.signal,
        onDelta: d => {
          bot.content += d;
          if (!raf) raf = requestAnimationFrame(() => { raf = 0; const stick = nearBottom(); const el = botEl(); if (el) setMd(el, bot.content); if (stick) toBottom(); });
        },
      });
      bot.streaming = false;
    } catch (e) {
      handleFailure(e, text, bot);
    } finally {
      st.ctrl = null; setBusy(false);
      if (bot) bot.streaming = false;
      drawLog();
      await syncAfter();
      drawComposer(); input.focus();
    }
  }

  function handleFailure(e, text, bot) {
    const aborted = e && e.name === 'AbortError';
    const code = aborted ? 'aborted' : (e.code || 'network');
    const partial = bot && bot.content && bot.content.trim();
    if (partial) { if (!aborted) st.msgs.push({ role: 'error', code }); return; }
    // لم يصل شيء: نزيل الرسالتين ونعيد النص للمحرر
    if (bot) { const i = st.msgs.indexOf(bot); if (i >= 0) st.msgs.splice(i, 1); }
    for (let i = st.msgs.length - 1; i >= 0; i--) { if (st.msgs[i].role === 'user' && st.msgs[i].content === text) { st.msgs.splice(i, 1); break; } }
    input.value = text; grow();
    if (!aborted) st.msgs.push({ role: 'error', code });
    if (!st.msgs.some(m => m.role !== 'error') && st.cur) {
      // محادثة جديدة فارغة: لا نتركها يتيمة في القائمة
      const id = st.cur.id; api.deleteConversation(id).catch(() => {});
      st.convs = st.convs.filter(c => c.id !== id); st.cur = null; history.replaceState(null, '', '#/chat'); drawSide(); drawHead();
    }
  }
  async function syncAfter() {
    try {
      const [, convs] = await Promise.all([refreshStatus(), api.listConversations()]);
      st.convs = convs;
      if (st.cur) st.cur = convs.find(c => c.id === st.cur.id) || st.cur;
      drawSide(); drawHead();
    } catch { /* ignore */ }
  }

  async function openConv(id) {
    if (st.busy) return;
    const c = st.convs.find(x => x.id === id);
    if (!c) return newChat();
    toggleSide(false);
    st.cur = c; st.msgs = []; log.replaceChildren(spinner());
    try {
      st.msgs = (await api.loadMessages(id)).map(m => ({ role: m.role, content: m.content }));
    } catch { toast(t('err.generic'), 'bad'); }
    const mm = S.catalog.modes.find(x => x.id === c.mode_id); if (mm && allowed(mm)) st.mode = mm;
    const tt = S.catalog.thinking.find(x => x.id === c.thinking_id); if (tt && allowed(tt)) st.thinking = tt;
    history.replaceState(null, '', '#/chat/' + id);
    drawSide(); drawHead(); drawLog();
  }
  function newChat() {
    if (st.busy) return;
    st.cur = null; st.msgs = []; toggleSide(false);
    history.replaceState(null, '', '#/chat');
    drawSide(); drawHead(); drawLog(); input.focus();
  }

  // ------------------------------------------------ البدء
  drawHead(); drawComposer(); drawSide(); log.append(spinner(t('common.loading')));
  try {
    st.convs = await api.listConversations();
  } catch (e) { toast(t('err.generic'), 'bad'); }
  drawSide();
  const want = ctx.parts[0];
  if (want && st.convs.some(c => c.id === want)) await openConv(want); else drawLog();
  setTimeout(() => { if (!matchMedia('(pointer: coarse)').matches) input.focus(); }, 60);
  root.cleanup = () => { if (st.ctrl) st.ctrl.abort(); };
  return root;
}
