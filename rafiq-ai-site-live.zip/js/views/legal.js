// الشروط والأحكام وسياسة الخصوصية — إعداد وتصميم / فهد مبارك
// النص الافتراضي من js/legal.js، ويستطيع المالك استبداله من لوحة التحكم (لكل لغة على حدة)
import { h } from '../ui.js';
import { t, getLang, fmt } from '../i18n.js';
import { LEGAL, LEGAL_DATE } from '../legal.js';
import { renderMarkdown } from '../markdown.js';
import { setting, siteName } from '../state.js';

const SETTING_KEY = { terms: 'legal_terms', privacy: 'legal_privacy' };

// فقرات النص الافتراضي: الأسطر التي تبدأ بـ «• » تتجمع في قائمة واحدة
function blocks(lines, site) {
  const out = [];
  let list = null;
  for (const raw of lines) {
    const line = raw.replace(/\{site\}/g, site);
    if (line.startsWith('• ')) {
      if (!list) { list = h('ul'); out.push(list); }
      list.append(h('li', null, line.slice(2)));
    } else { list = null; out.push(h('p', null, line)); }
  }
  return out;
}

export function contactLine() {
  const email = String(setting('contact_email', '') || '').trim();
  const wa = String(setting('contact_whatsapp', '') || '').replace(/[^\d]/g, '');
  const parts = [];
  if (email) parts.push(h('a', { href: 'mailto:' + email, dir: 'ltr' }, email));
  if (wa) parts.push(h('a', { href: 'https://wa.me/' + wa, target: '_blank', rel: 'noopener noreferrer', dir: 'ltr' }, '+' + wa));
  if (!parts.length) return h('p', { class: 'legal-contact' }, t('legal.contactNone'));
  const joined = [];
  parts.forEach((p, i) => { if (i) joined.push(' · '); joined.push(p); });
  return h('p', { class: 'legal-contact' }, t('legal.contact') + ' ', ...joined);
}

export function legalView(ctx, kind) {
  const lang = getLang();
  const site = siteName();
  const override = setting(SETTING_KEY[kind], {});
  const custom = override && typeof override === 'object' ? String(override[lang] || '').trim() : '';
  const doc = LEGAL[kind][lang] || LEGAL[kind].en;

  let body;
  if (custom) {
    body = h('div', { class: 'md legal-body' });
    body.innerHTML = renderMarkdown(custom);          // المُحوِّل يهرّب كل شيء ويسمح بروابط http(s) فقط
  } else {
    body = h('div', { class: 'legal-body' }, doc.sections.map(([heading, lines]) => h('section', null, h('h2', null, heading), ...blocks(lines, site))));
  }

  return h('div', { class: 'page legal-page' },
    h('article', { class: 'legal' },
      h('header', { class: 'legal-head' },
        h('h1', null, kind === 'terms' ? t('legal.terms') : t('legal.privacy')),
        h('p', { class: 'muted' }, t('legal.updated', { date: fmt.date(LEGAL_DATE) }))),
      body,
      contactLine(),
      h('p', { class: 'legal-back' }, h('a', { href: '#/' }, t('common.back')))));
}
