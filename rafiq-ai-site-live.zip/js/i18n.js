// الترجمة وتنسيق الأرقام والتواريخ — إعداد وتصميم / فهد مبارك
import ar from './lang/ar.js';
import en from './lang/en.js';
import fr from './lang/fr.js';
import ur from './lang/ur.js';
import admin from './lang/admin.js';

const DICT = { ar: { ...ar, ...admin.ar }, en: { ...en, ...admin.en }, fr, ur };

export const LANGS = {
  ar: { label: 'العربية', dir: 'rtl', locale: 'ar-u-nu-latn' },
  en: { label: 'English', dir: 'ltr', locale: 'en-u-nu-latn' },
  fr: { label: 'Français', dir: 'ltr', locale: 'fr-u-nu-latn' },
  ur: { label: 'اردو', dir: 'rtl', locale: 'ur-u-nu-latn' },
};
export const DICTIONARIES = DICT;

let lang = 'ar';
export const getLang = () => lang;
export const isRtl = () => LANGS[lang].dir === 'rtl';

export function detectLang(allowed, fallback = 'ar') {
  let saved = null;
  try { saved = localStorage.getItem('rafiq.lang'); } catch { /* ignore */ }
  if (saved && allowed.includes(saved)) return saved;
  const nav = (navigator.language || '').slice(0, 2).toLowerCase();
  if (allowed.includes(nav)) return nav;
  return allowed.includes(fallback) ? fallback : allowed[0];
}

export function setLang(l, persist = true) {
  if (!LANGS[l]) l = 'ar';
  lang = l;
  document.documentElement.lang = l;
  document.documentElement.dir = LANGS[l].dir;
  if (persist) { try { localStorage.setItem('rafiq.lang', l); } catch { /* ignore */ } }
}

export function t(key, vars) {
  let s = DICT[lang]?.[key] ?? DICT.en[key] ?? DICT.ar[key];
  if (s === undefined) return key;
  if (vars) s = s.replace(/\{(\w+)\}/g, (_, k) => (vars[k] ?? ''));
  return s;
}

/** قيمة متعددة اللغات قادمة من قاعدة البيانات: {ar, en, fr, ur} */
export function tr(v) {
  if (v === null || v === undefined) return '';
  if (typeof v === 'string') return v;
  if (Array.isArray(v)) return v;
  return v[lang] || v.en || v.ar || Object.values(v).find(Boolean) || '';
}
/** قائمة نصوص متعددة اللغات: {ar:[...], en:[...]} */
export function trList(v) {
  if (!v) return [];
  const x = v[lang] || v.en || v.ar || [];
  return Array.isArray(x) ? x : [];
}

const locale = () => LANGS[lang].locale;
export const fmt = {
  num: n => new Intl.NumberFormat(locale()).format(Number(n) || 0),
  money(n) {
    n = Number(n) || 0;
    const s = new Intl.NumberFormat(locale(), { minimumFractionDigits: Number.isInteger(n) ? 0 : 2, maximumFractionDigits: 2 }).format(n);
    return t('money.fmt', { n: s });
  },
  date: d => (d ? new Intl.DateTimeFormat(locale(), { dateStyle: 'medium' }).format(new Date(d)) : ''),
  datetime: d => (d ? new Intl.DateTimeFormat(locale(), { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(d)) : ''),
  daysLeft: d => Math.max(0, Math.ceil((new Date(d) - Date.now()) / 86400000)),
};
