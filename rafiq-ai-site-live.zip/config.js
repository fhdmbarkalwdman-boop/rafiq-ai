// ==========================================================================
//  إعدادات الموقع — هذا هو الملف الوحيد الذي تعدّله بعد رفع الموقع.
//  إعداد وتصميم / فهد مبارك
//
//  1) افتح مشروعك في Supabase ثم: Project Settings → API
//  2) انسخ "Project URL" وضعه في SUPABASE_URL
//  3) انسخ المفتاح العام (anon / publishable key) وضعه في SUPABASE_ANON_KEY
//
//  تنبيه: هذا هو المفتاح العام فقط، ولا بأس أن يظهر في الموقع.
//  لا تضع هنا أبداً مفتاح service_role ولا مفتاح الذكاء الاصطناعي.
// ==========================================================================
window.RAFIQ_CONFIG = {
  SUPABASE_URL: "https://pewuejydneodjrrxylar.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_oSZPBrOrP7paJBgW2zlFPQ_LI599UE6",

  // اختياري: اللغات المتاحة واللغة الافتراضية
  // LANGS: ["ar", "en", "fr", "ur"],
  // DEFAULT_LANG: "ar",
};
