// يحدد اللغة والمظهر قبل أول رسم لتجنّب الوميض (ملف منفصل ليعمل مع سياسة أمان المحتوى CSP)
(function () {
  try {
    var L = ['ar', 'en', 'fr', 'ur'];
    var l = localStorage.getItem('rafiq.lang');
    if (L.indexOf(l) < 0) { var n = (navigator.language || '').slice(0, 2).toLowerCase(); l = L.indexOf(n) >= 0 ? n : 'ar'; }
    document.documentElement.lang = l;
    document.documentElement.dir = (l === 'ar' || l === 'ur') ? 'rtl' : 'ltr';
    var th = localStorage.getItem('rafiq.theme');
    if (th === 'light' || th === 'dark') document.documentElement.setAttribute('data-theme', th);
  } catch (e) { /* ignore */ }
})();
