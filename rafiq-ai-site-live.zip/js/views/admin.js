// لوحة تحكم المالك — إعداد وتصميم / فهد مبارك
import { h, icon, ICON_NAMES, toast, openModal, confirmDialog, spinner, debounce } from '../ui.js';
import { t, tr, fmt, LANGS, getLang } from '../i18n.js';
import * as api from '../api.js';
import { S, refreshCatalog, realPaymentText } from '../state.js';

const SECTIONS = [['overview', 'gauge'], ['orders', 'receipt'], ['users', 'users'], ['plans', 'star'], ['offers', 'tag'], ['modes', 'sparkle'], ['thinking', 'brain'], ['settings', 'settings']];
const langList = () => Object.keys(LANGS).filter(l => (api.config.LANGS || Object.keys(LANGS)).includes(l));
const NS = 'http://www.w3.org/2000/svg';
function svg(tag, attrs = {}, ...kids) {
  const el = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) el.setAttribute(k, v);
  for (const k of kids) if (k) el.append(k);
  return el;
}

// ============================================================ نماذج عامة
function buildForm(fields, rec, isEdit) {
  const readers = [];
  const rows = fields.map(f => {
    const id = 'f-' + f.key;
    const val = rec[f.key];
    let control, read;
    switch (f.type) {
      case 'number': {
        control = h('input', { id, class: 'input', type: 'number', step: f.step ?? 1, min: f.min, max: f.max, value: val ?? '', dir: 'ltr' });
        read = () => {
          if (control.value === '') return f.nullable ? null : (f.required ? NaN : (f.default ?? 0));
          const n = Number(control.value);
          return f.zeroNull && n === 0 ? null : n;
        };
        break;
      }
      case 'textarea': {
        control = h('textarea', { id, class: 'input mono-ish', rows: f.rows || 4 }); control.value = val ?? '';
        read = () => control.value.trim();
        break;
      }
      case 'check': {
        control = h('input', { id, type: 'checkbox', checked: !!val, class: 'check' });
        read = () => control.checked;
        break;
      }
      case 'select': {
        control = h('select', { id, class: 'input' }, f.options.map(o => h('option', { value: o.value, selected: String(o.value) === String(val ?? f.default ?? '') }, o.label)));
        read = () => (f.numeric ? Number(control.value) : control.value);
        break;
      }
      case 'i18n': {
        const inputs = {};
        control = h('div', { class: 'i18n' }, langList().map(l => {
          const inp = f.multiline ? h('textarea', { class: 'input', rows: f.rows || 3, dir: LANGS[l].dir }) : h('input', { class: 'input', dir: LANGS[l].dir });
          inp.value = (val && val[l]) || ''; inputs[l] = inp;
          return h('label', { class: 'i18n-row' }, h('span', { class: 'i18n-tag' }, l.toUpperCase()), inp);
        }));
        read = () => Object.fromEntries(Object.entries(inputs).map(([l, i]) => [l, i.value.trim()]).filter(([, v]) => v));
        break;
      }
      case 'i18nlines': {
        const inputs = {};
        control = h('div', { class: 'i18n' }, langList().map(l => {
          const inp = h('textarea', { class: 'input', rows: 3, dir: LANGS[l].dir, placeholder: t('a.f.onePerLine') });
          inp.value = ((val && val[l]) || []).join('\n'); inputs[l] = inp;
          return h('label', { class: 'i18n-row' }, h('span', { class: 'i18n-tag' }, l.toUpperCase()), inp);
        }));
        read = () => Object.fromEntries(Object.entries(inputs).map(([l, i]) => [l, i.value.split('\n').map(s => s.trim()).filter(Boolean)]).filter(([, v]) => v.length));
        break;
      }
      case 'datetime': {
        const local = val ? new Date(new Date(val).getTime() - new Date(val).getTimezoneOffset() * 60000).toISOString().slice(0, 16) : '';
        control = h('input', { id, class: 'input', type: 'datetime-local', value: local, dir: 'ltr' });
        read = () => (control.value ? new Date(control.value).toISOString() : null);
        break;
      }
      case 'plans': {
        const sel = new Set(val || []);
        control = h('div', { class: 'checks' }, S.catalog.plans.map(p => h('label', { class: 'check-row' }, h('input', { type: 'checkbox', class: 'check', value: p.id, checked: sel.has(p.id) }), tr(p.name))));
        read = () => { const a = [...control.querySelectorAll('input:checked')].map(i => i.value); return a.length ? a : null; };
        break;
      }
      case 'icon': {
        let cur = val || f.default || ICON_NAMES[0];
        control = h('div', { class: 'icon-grid' }, ICON_NAMES.map(n => h('button', {
          type: 'button', class: 'icon-pick' + (n === cur ? ' on' : ''), title: n, dataset: { n },
          onclick: () => { cur = n; control.querySelectorAll('.icon-pick').forEach(b => b.classList.toggle('on', b.dataset.n === n)); },
        }, icon(n, 20))));
        read = () => cur;
        break;
      }
      default: {
        control = h('input', { id, class: 'input', value: val ?? '', dir: f.ltr ? 'ltr' : null, maxlength: f.maxlength, readOnly: !!(isEdit && f.readonlyOnEdit), placeholder: f.placeholder });
        read = () => control.value.trim();
      }
    }
    readers.push({ f, read, control });
    return h('div', { class: 'field' + (f.type === 'check' ? ' inline' : '') },
      f.type === 'check' ? [control, h('label', { class: 'label', for: id }, t(f.label))] : [h('label', { class: 'label', for: id }, t(f.label)), control],
      f.hint ? h('p', { class: 'hint' }, t(f.hint)) : null);
  });
  const err = h('p', { class: 'form-error', role: 'alert', hidden: true });
  return {
    el: h('div', { class: 'admin-form' }, rows, err),
    read() {
      err.hidden = true;
      const out = {};
      for (const { f, read, control } of readers) {
        if (f.key.startsWith('_')) continue;
        const v = read();
        if (f.required && (v === '' || v === null || (typeof v === 'number' && Number.isNaN(v)))) { err.textContent = t('a.err.required', { f: t(f.label) }); err.hidden = false; control.focus?.(); return null; }
        if (f.required && f.type === 'i18n' && !Object.keys(v).length) { err.textContent = t('a.err.required', { f: t(f.label) }); err.hidden = false; return null; }
        if (f.pattern && v && !f.pattern.test(v)) { err.textContent = t('a.err.pattern', { f: t(f.label) }); err.hidden = false; control.focus?.(); return null; }
        out[f.key] = f.emptyNull && (v === '' || v === undefined) ? null : v;
      }
      return out;
    },
    fail(msg) { err.textContent = msg; err.hidden = false; },
  };
}

function dataTable(cols, rows, empty) {
  if (!rows.length) return h('p', { class: 'muted pad' }, empty || t('a.empty'));
  return h('div', { class: 'table-wrap' }, h('table', { class: 'tbl' },
    h('thead', null, h('tr', null, cols.map(c => h('th', { class: c.cls }, t(c.label))))),
    h('tbody', null, rows.map(r => h('tr', null, cols.map(c => h('td', { class: c.cls, 'data-label': t(c.label) }, c.render(r))))))));
}
const yesNo = v => (v ? h('span', { class: 'chip chip-ok' }, t('a.on')) : h('span', { class: 'chip chip-muted' }, t('a.off')));
const pageHead = (title, ...actions) => h('header', { class: 'admin-head' }, h('h1', null, title), h('div', { class: 'row-inline' }, actions));

// ============================================================ إدارة جدول (باقات، عروض، أنماط، أنظمة تفكير)
function crud({ title, table, idKey, fields, columns, defaults, order, textId, afterSave, validate }) {
  const box = h('div', { class: 'crud' });
  let rows = [];
  async function load() {
    box.replaceChildren(spinner());
    try {
      rows = table === 'offers' ? await api.admin.offers() : await api.admin.list(table, order || 'sort');
      draw();
    } catch (e) { box.replaceChildren(h('p', { class: 'form-error' }, String(e.message || e))); }
  }
  function edit(rec) {
    const isEdit = !!rec;
    const form = buildForm(fields, rec || defaults(), isEdit);
    const save = h('button', { class: 'btn btn-primary', type: 'button' }, t('common.save'));
    const m = openModal({ title: (isEdit ? t('a.edit') : t('a.add')) + ': ' + title, size: 'lg', body: form.el, footer: [h('button', { class: 'btn btn-ghost', type: 'button', onclick: () => m.close() }, t('common.cancel')), save] });
    save.addEventListener('click', async () => {
      const data = form.read(); if (!data) return;
      const bad = validate && validate(data);
      if (bad) { form.fail(t(bad)); return; }
      save.disabled = true;
      try {
        if (isEdit) { const { [idKey]: _id, ...rest } = data; await api.admin.update(table, idKey, rec[idKey], textId ? rest : data); }
        else await api.admin.insert(table, data);
        await refreshCatalog(); if (afterSave) afterSave();
        m.close(); toast(t('a.saved'), 'ok'); load();
      } catch (e) {
        save.disabled = false;
        const msg = String(e.raw?.message || e.message || '');
        form.fail(/duplicate|already exists|unique/i.test(msg) ? t('a.err.duplicate') : (/violates|check constraint/i.test(msg) ? t('a.err.invalid') : msg || t('err.generic')));
      }
    });
  }
  function draw() {
    const cols = [...columns, { label: 'a.col.actions', cls: 'actions', render: r => h('div', { class: 'row-inline' },
      h('button', { class: 'icon-btn xs', type: 'button', 'aria-label': t('a.edit'), onclick: () => edit(r) }, icon('edit', 15)),
      h('button', { class: 'icon-btn xs danger', type: 'button', 'aria-label': t('common.delete'), onclick: async () => {
        if (!(await confirmDialog(t('a.deleteConfirm'), { okLabel: t('common.delete'), cancelLabel: t('common.cancel'), danger: true }))) return;
        try { await api.admin.remove(table, idKey, r[idKey]); await refreshCatalog(); toast(t('a.deleted'), 'ok'); load(); }
        catch (e) { toast(/foreign key|violates/i.test(String(e.raw?.message || '')) ? t('a.err.inUse') : t('err.generic'), 'bad'); }
      } }, icon('trash', 15))) }];
    box.replaceChildren(dataTable(cols, rows));
  }
  const root = h('div', null, pageHead(title, h('button', { class: 'btn btn-primary', type: 'button', onclick: () => edit(null) }, icon('plus', 18), t('a.add'))), box);
  load();
  return root;
}

// ============================================================ الأقسام
async function overview(ctx, stats) {
  const root = h('div', { class: 'overview' });
  const s = stats;
  const card = (k, v, ico, hot) => h('div', { class: 'stat' + (hot ? ' hot' : '') }, h('span', { class: 'stat-ico' }, icon(ico, 20)), h('div', null, h('strong', null, v), h('span', { class: 'muted small' }, t('a.stat.' + k))));
  const cards = h('div', { class: 'stats' },
    card('pending_orders', fmt.num(s.pending_orders), 'receipt', Number(s.pending_orders) > 0),
    card('active_subs', fmt.num(s.active_subs), 'star'),
    card('revenue_total', fmt.money(s.revenue_total), 'tag'),
    card('revenue_30d', fmt.money(s.revenue_30d), 'tag'),
    card('users_total', fmt.num(s.users_total), 'users'),
    card('users_7d', fmt.num(s.users_7d), 'user'),
    card('messages_today', fmt.num(s.messages_today), 'chat'),
    card('messages_7d', fmt.num(s.messages_7d), 'chat'));

  // مخطط آخر 14 يوماً
  const series = s.series || [];
  const W = 640, H = 190, pad = { l: 34, r: 10, t: 14, b: 26 };
  const maxV = Math.max(4, ...series.map(d => Math.max(Number(d.messages), Number(d.signups))));
  const nice = Math.ceil(maxV / 4) * 4;
  const bw = (W - pad.l - pad.r) / Math.max(series.length, 1);
  const y = v => pad.t + (H - pad.t - pad.b) * (1 - v / nice);
  const chart = svg('svg', { viewBox: `0 0 ${W} ${H}`, class: 'chart', role: 'img', 'aria-label': t('a.chart.title') });
  for (let i = 0; i <= 4; i++) {
    const v = (nice / 4) * i;
    chart.append(svg('line', { x1: pad.l, x2: W - pad.r, y1: y(v), y2: y(v), class: 'grid' }));
    const lab = svg('text', { x: pad.l - 6, y: y(v) + 4, class: 'axis', 'text-anchor': 'end' }); lab.textContent = fmt.num(v); chart.append(lab);
  }
  series.forEach((d, i) => {
    const x = pad.l + i * bw + bw * 0.18, w = bw * 0.64;
    const bar = svg('rect', { x, y: y(Number(d.messages)), width: w, height: Math.max(0, y(0) - y(Number(d.messages))), rx: 3, class: 'bar' });
    const tt = svg('title'); tt.textContent = `${d.day}: ${d.messages} / ${d.signups}`; bar.append(tt); chart.append(bar);
    if (i % 3 === 0 || i === series.length - 1) { const lab = svg('text', { x: x + w / 2, y: H - 8, class: 'axis', 'text-anchor': 'middle' }); lab.textContent = d.day.slice(5); chart.append(lab); }
  });
  const pts = series.map((d, i) => `${pad.l + i * bw + bw / 2},${y(Number(d.signups))}`).join(' ');
  chart.append(svg('polyline', { points: pts, class: 'line', fill: 'none' }));
  series.forEach((d, i) => chart.append(svg('circle', { cx: pad.l + i * bw + bw / 2, cy: y(Number(d.signups)), r: 3.2, class: 'dot' })));
  const chartCard = h('section', { class: 'card' }, h('h2', { class: 'card-title' }, icon('chart', 20), t('a.chart.title')),
    h('div', { class: 'legend' }, h('span', null, h('i', { class: 'sw bar' }), t('a.chart.messages')), h('span', null, h('i', { class: 'sw line' }), t('a.chart.signups'))),
    h('div', { class: 'chart-wrap' }, chart));

  // حالة الذكاء الاصطناعي
  const aiOut = h('div', { class: 'ai-out', 'aria-live': 'polite' }, h('p', { class: 'muted' }, t('a.ai.intro')));
  const aiBtn = h('button', { class: 'btn btn-primary', type: 'button', onclick: async () => {
    aiBtn.disabled = true; aiOut.replaceChildren(spinner(t('a.ai.testing')));
    const r = await api.testAI();
    aiBtn.disabled = false;
    const info = r.provider ? h('p', { class: 'muted small', dir: 'ltr' }, `${r.provider} / ${r.model}${r.smart_model && r.smart_model !== r.model ? ' / ' + r.smart_model : ''}`) : null;
    if (r.ok) aiOut.replaceChildren(h('div', { class: 'ai-res ok' }, icon('check', 20), h('div', null, h('strong', null, t('a.ai.ok')), info)));
    else {
      const key = { ai_not_configured: 'a.ai.notConfigured', ai_auth: 'a.ai.auth', function_missing: 'a.ai.functionMissing', ai_rate: 'a.ai.rate', network: 'a.ai.network' }[r.error] || 'a.ai.failed';
      aiOut.replaceChildren(h('div', { class: 'ai-res bad' }, icon('shield', 20), h('div', null, h('strong', null, t(key)), info, r.detail ? h('p', { class: 'small', dir: 'ltr' }, r.detail) : null)));
    }
  } }, icon('bolt', 18), t('a.ai.test'));
  const aiCard = h('section', { class: 'card' }, h('h2', { class: 'card-title' }, icon('bolt', 20), t('a.ai.title')), aiOut, aiBtn);

  // قائمة تحقق للإعداد
  const settings = S.catalog.settings;
  const todo = [
    [!!realPaymentText(settings.payment_instructions, getLang()), 'a.check.payment', 'settings'],
    [(S.catalog.offers || []).length > 0, 'a.check.offer', 'offers'],
    [!!(settings.contact_whatsapp || settings.contact_email), 'a.check.contact', 'settings'],
  ];
  const checkCard = h('section', { class: 'card' }, h('h2', { class: 'card-title' }, icon('list', 20), t('a.check.title')),
    h('ul', { class: 'checklist' }, todo.map(([done, label, to]) => h('li', { class: done ? 'done' : '' }, icon(done ? 'check' : 'close', 16), h('span', null, t(label)),
      done ? null : h('a', { href: '#/admin/' + to, class: 'small' }, t('a.check.fix'))))));

  root.append(pageHead(t('a.nav.overview')), cards, h('div', { class: 'two' }, chartCard, h('div', { class: 'col' }, aiCard, checkCard)));
  return root;
}

async function ordersSection() {
  let filter = 'pending';
  const body = h('div');
  const tabs = h('div', { class: 'tabs', role: 'tablist' });
  async function load() {
    tabs.replaceChildren(...['pending', 'approved', 'rejected', 'cancelled', 'all'].map(k => h('button', { class: 'tab' + (k === filter ? ' on' : ''), type: 'button', role: 'tab', onclick: () => { filter = k; load(); } }, k === 'all' ? t('a.all') : t('order.status.' + k))));
    body.replaceChildren(spinner());
    const rows = await api.admin.orders(filter);
    body.replaceChildren(dataTable([
      { label: 'a.col.date', cls: 'nw', render: r => fmt.datetime(r.created_at) },
      { label: 'a.col.user', render: r => h('div', null, h('strong', null, r.user?.full_name || '-'), h('div', { class: 'muted small', dir: 'ltr' }, r.user?.email || '')) },
      { label: 'a.col.plan', render: r => tr(S.catalog.plans.find(p => p.id === r.plan_id)?.name) || r.plan_id },
      { label: 'a.col.amount', render: r => h('div', null, h('strong', null, fmt.money(r.amount)), Number(r.discount) > 0 ? h('div', { class: 'muted small' }, '− ' + fmt.money(r.discount) + (r.coupon_code ? ' (' + r.coupon_code + ')' : '')) : null) },
      { label: 'a.col.method', cls: 'nw', render: r => t('checkout.method.' + r.method) },
      { label: 'a.col.reference', cls: 'nw', render: r => h('div', null, h('span', { dir: 'ltr' }, r.reference || '-'), r.note ? h('div', { class: 'muted small nw-off' }, r.note) : null) },
      { label: 'a.col.status', render: r => h('span', { class: 'chip chip-' + ({ pending: 'warn', approved: 'ok', rejected: 'bad', cancelled: 'muted' }[r.status]) }, t('order.status.' + r.status)) },
      { label: 'a.col.actions', cls: 'actions', render: r => r.status === 'pending' ? h('div', { class: 'row-inline' },
        h('button', { class: 'btn btn-primary btn-sm', type: 'button', onclick: () => decide(r, true) }, t('a.approve')),
        h('button', { class: 'btn btn-danger-ghost btn-sm', type: 'button', onclick: () => decide(r, false) }, t('a.reject'))) : (r.admin_note ? h('span', { class: 'muted small' }, r.admin_note) : null) },
    ], rows, t('a.orders.empty')));
  }
  function decide(r, approve) {
    const note = h('textarea', { id: 'dn', class: 'input', rows: 2, placeholder: t('a.note.ph') });
    const ok = h('button', { class: 'btn ' + (approve ? 'btn-primary' : 'btn-danger'), type: 'button' }, approve ? t('a.approve') : t('a.reject'));
    const m = openModal({ title: (approve ? t('a.approve') : t('a.reject')) + ': ' + fmt.money(r.amount), size: 'sm',
      body: h('div', null, h('div', { class: 'checkout' }, h('strong', { dir: 'ltr' }, r.user?.email || ''), h('span', null, tr(S.catalog.plans.find(p => p.id === r.plan_id)?.name)), h('span', { class: 'muted', dir: 'ltr' }, '#' + (r.reference || '-'))), approve ? h('p', { class: 'hint' }, t('a.approve.hint')) : null, h('label', { class: 'label', for: 'dn' }, t('a.note')), note),
      footer: [h('button', { class: 'btn btn-ghost', type: 'button', onclick: () => m.close() }, t('common.cancel')), ok] });
    ok.addEventListener('click', async () => {
      ok.disabled = true;
      try { await api.admin.decide(r.id, approve, note.value.trim()); m.close(); toast(t('a.saved'), 'ok'); load(); }
      catch (e) { ok.disabled = false; toast(e.code === 'already_decided' ? t('a.err.decided') : t('err.generic'), 'bad'); }
    });
  }
  const root = h('div', null, pageHead(t('a.nav.orders')), tabs, body);
  await load();
  return root;
}

async function usersSection() {
  const body = h('div');
  const search = h('input', { id: 'u-search', class: 'input', type: 'search', placeholder: t('a.users.search') });
  async function load() {
    body.replaceChildren(spinner());
    const rows = await api.admin.users(search.value.trim());
    body.replaceChildren(dataTable([
      { label: 'a.col.user', render: r => h('div', null, h('strong', null, r.full_name || '-'), h('div', { class: 'muted small', dir: 'ltr' }, r.email)) },
      { label: 'a.col.role', render: r => h('div', { class: 'row-inline wrap' }, h('span', { class: 'chip ' + (r.role === 'admin' ? 'chip-offer' : 'chip-muted') }, t('a.role.' + r.role)), r.banned ? h('span', { class: 'chip chip-bad' }, t('a.banned')) : null) },
      { label: 'a.col.plan', render: r => r.plan_id ? h('div', null, h('strong', null, tr(S.catalog.plans.find(p => p.id === r.plan_id)?.name) || r.plan_id), h('div', { class: 'muted small' }, fmt.date(r.ends_at))) : h('span', { class: 'muted' }, '-') },
      { label: 'a.col.messages', render: r => fmt.num(r.messages) },
      { label: 'a.col.joined', render: r => fmt.date(r.created_at) },
      { label: 'a.col.actions', cls: 'actions', render: r => h('button', { class: 'btn btn-secondary btn-sm', type: 'button', onclick: () => manage(r) }, t('a.manage')) },
    ], rows));
  }
  function manage(u) {
    const planSel = h('select', { id: 'g-plan', class: 'input' }, S.catalog.plans.map(p => h('option', { value: p.id }, `${tr(p.name)} (${fmt.money(p.price_sar)})`)));
    const days = h('input', { id: 'g-days', class: 'input', type: 'number', min: 1, placeholder: t('a.grant.daysPh'), dir: 'ltr' });
    const act = async (fn, okMsg) => { try { await fn(); toast(okMsg || t('a.saved'), 'ok'); m.close(); load(); } catch (e) { toast(e.code === 'cannot_change_self' ? t('a.err.self') : t('err.generic'), 'bad'); } };
    const m = openModal({ title: u.full_name || u.email, size: 'md', body: h('div', { class: 'manage' },
      h('p', { class: 'muted', dir: 'ltr' }, u.email),
      h('h4', { class: 'sec-title' }, t('a.grant.title')),
      h('div', { class: 'grid-2' }, h('div', { class: 'field' }, h('label', { class: 'label', for: 'g-plan' }, t('a.col.plan')), planSel), h('div', { class: 'field' }, h('label', { class: 'label', for: 'g-days' }, t('a.grant.days')), days)),
      h('div', { class: 'row-inline wrap' },
        h('button', { class: 'btn btn-primary', type: 'button', onclick: () => act(() => api.admin.grant(u.id, planSel.value, days.value ? Number(days.value) : null)) }, t('a.grant.btn')),
        u.plan_id ? h('button', { class: 'btn btn-danger-ghost', type: 'button', onclick: () => act(() => api.admin.cancelSub(u.id)) }, t('a.grant.cancel')) : null),
      h('h4', { class: 'sec-title' }, t('a.account')),
      h('div', { class: 'row-inline wrap' },
        h('button', { class: 'btn btn-secondary', type: 'button', onclick: () => act(() => api.admin.setUser(u.id, u.role === 'admin' ? 'user' : 'admin', u.banned)) }, u.role === 'admin' ? t('a.removeAdmin') : t('a.makeAdmin')),
        h('button', { class: 'btn ' + (u.banned ? 'btn-secondary' : 'btn-danger-ghost'), type: 'button', onclick: () => act(() => api.admin.setUser(u.id, u.role, !u.banned)) }, u.banned ? t('a.unban') : t('a.ban')))) });
  }
  search.addEventListener('input', debounce(load, 350));
  const root = h('div', null, pageHead(t('a.nav.users')), h('div', { class: 'toolbar' }, search), body);
  await load();
  return root;
}

const tierOptions = () => [{ value: 0, label: t('a.tier.free') }, ...S.catalog.plans.map(p => ({ value: p.tier, label: `${tr(p.name)} (${p.tier}+)` }))];

function plansSection() {
  return crud({
    title: t('a.nav.plans'), table: 'plans', idKey: 'id', textId: true,
    defaults: () => ({ id: '', tier: S.catalog.plans.length + 1, price_sar: 49, duration_days: 365, daily_limit: 30, active: true, sort: S.catalog.plans.length + 1, name: {}, description: {}, features: {} }),
    fields: [
      { key: 'id', label: 'a.f.id', required: true, readonlyOnEdit: true, ltr: true, pattern: /^[a-z0-9_-]{2,30}$/, hint: 'a.f.id.hint' },
      { key: 'name', type: 'i18n', label: 'a.f.name', required: true },
      { key: 'description', type: 'i18n', label: 'a.f.description' },
      { key: 'features', type: 'i18nlines', label: 'a.f.features', hint: 'a.f.features.hint' },
      { key: 'price_sar', type: 'number', step: 0.5, min: 0, required: true, label: 'a.f.price' },
      { key: 'tier', type: 'number', min: 1, max: 9, required: true, label: 'a.f.tier', hint: 'a.f.tier.hint' },
      { key: 'daily_limit', type: 'number', min: 1, required: true, label: 'a.f.dailyLimit' },
      { key: 'duration_days', type: 'number', min: 1, required: true, label: 'a.f.duration' },
      { key: 'sort', type: 'number', label: 'a.f.sort' },
      { key: 'highlight', type: 'check', label: 'a.f.highlight' },
      { key: 'active', type: 'check', label: 'a.f.active' },
    ],
    columns: [
      { label: 'a.f.name', render: r => h('div', null, h('strong', null, tr(r.name)), h('div', { class: 'muted small', dir: 'ltr' }, r.id)) },
      { label: 'a.f.price', render: r => fmt.money(r.price_sar) },
      { label: 'a.f.tier', render: r => r.tier },
      { label: 'a.f.dailyLimit', render: r => fmt.num(r.daily_limit) },
      { label: 'a.f.active', render: r => yesNo(r.active) },
    ],
  });
}

function offerWindow(r) {
  if (r.starts_at && r.ends_at) return `${fmt.date(r.starts_at)} – ${fmt.date(r.ends_at)}`;
  if (r.ends_at) return t('a.until', { d: fmt.date(r.ends_at) });
  if (r.starts_at) return t('a.from', { d: fmt.date(r.starts_at) });
  return t('a.always');
}

function offersSection() {
  return crud({
    title: t('a.nav.offers'), table: 'offers', idKey: 'id', order: 'created_at',
    defaults: () => ({ active: true, title: {}, description: {}, percent_off: null }),
    validate: d => (Number(d.percent_off) > 0 || Number(d.amount_off) > 0 ? null : 'a.err.discount'),
    fields: [
      { key: 'title', type: 'i18n', label: 'a.f.title', required: true },
      { key: 'description', type: 'i18n', label: 'a.f.description' },
      { key: 'code', label: 'a.f.code', ltr: true, emptyNull: true, pattern: /^[A-Za-z0-9_-]{3,30}$/, hint: 'a.f.code.hint', maxlength: 30 },
      { key: 'percent_off', type: 'number', step: 0.5, min: 0, max: 100, nullable: true, zeroNull: true, emptyNull: true, label: 'a.f.percent' },
      { key: 'amount_off', type: 'number', step: 0.5, min: 0, nullable: true, zeroNull: true, emptyNull: true, label: 'a.f.amountOff' },
      { key: 'plan_ids', type: 'plans', label: 'a.f.plans', hint: 'a.f.plans.hint' },
      { key: 'starts_at', type: 'datetime', label: 'a.f.starts' },
      { key: 'ends_at', type: 'datetime', label: 'a.f.ends' },
      { key: 'max_uses', type: 'number', min: 1, nullable: true, emptyNull: true, label: 'a.f.maxUses' },
      { key: 'active', type: 'check', label: 'a.f.active' },
    ],
    columns: [
      { label: 'a.f.title', render: r => h('div', null, h('strong', null, tr(r.title)), h('div', { class: 'muted small' }, r.code ? h('span', { dir: 'ltr' }, r.code) : t('a.offer.auto'))) },
      { label: 'a.f.discount', render: r => (Number(r.percent_off) > 0 ? fmt.num(Number(r.percent_off)) + '%' : '') + (Number(r.amount_off) > 0 ? ' ' + fmt.money(r.amount_off) : '') },
      { label: 'a.f.window', cls: 'nw', render: r => offerWindow(r) },
      { label: 'a.f.uses', render: r => h('span', { dir: 'ltr' }, `${fmt.num(r.uses)}${r.max_uses ? ' / ' + fmt.num(r.max_uses) : ''}`) },
      { label: 'a.f.active', render: r => yesNo(r.active) },
    ],
  });
}

function modesSection() {
  return crud({
    title: t('a.nav.modes'), table: 'modes', idKey: 'id', textId: true,
    defaults: () => ({ id: '', icon: 'chat', min_tier: 0, active: true, sort: S.catalog.modes.length + 1, name: {}, description: {}, starters: {}, system_prompt: '' }),
    fields: [
      { key: 'id', label: 'a.f.id', required: true, readonlyOnEdit: true, ltr: true, pattern: /^[a-z0-9_-]{2,30}$/, hint: 'a.f.id.hint' },
      { key: 'icon', type: 'icon', label: 'a.f.icon', default: 'chat' },
      { key: 'name', type: 'i18n', label: 'a.f.name', required: true },
      { key: 'description', type: 'i18n', label: 'a.f.description' },
      { key: 'system_prompt', type: 'textarea', rows: 7, label: 'a.f.systemPrompt', hint: 'a.f.systemPrompt.hint', required: true },
      { key: 'starters', type: 'i18nlines', label: 'a.f.starters', hint: 'a.f.starters.hint' },
      { key: 'min_tier', type: 'select', numeric: true, options: tierOptions(), label: 'a.f.minTier' },
      { key: 'sort', type: 'number', label: 'a.f.sort' },
      { key: 'active', type: 'check', label: 'a.f.active' },
    ],
    columns: [
      { label: 'a.f.name', render: r => h('div', { class: 'row-inline' }, icon(r.icon, 18), h('div', null, h('strong', null, tr(r.name)), h('div', { class: 'muted small', dir: 'ltr' }, r.id))) },
      { label: 'a.f.minTier', render: r => tierOptions().find(o => o.value === r.min_tier)?.label || r.min_tier },
      { label: 'a.f.sort', render: r => r.sort },
      { label: 'a.f.active', render: r => yesNo(r.active) },
    ],
  });
}

function thinkingSection() {
  return crud({
    title: t('a.nav.thinking'), table: 'thinking_systems', idKey: 'id', textId: true,
    defaults: () => ({ id: '', icon: 'brain', model_tier: 'fast', max_tokens: 1500, min_tier: 0, active: true, sort: S.catalog.thinking.length + 1, name: {}, description: {}, instruction: '' }),
    fields: [
      { key: 'id', label: 'a.f.id', required: true, readonlyOnEdit: true, ltr: true, pattern: /^[a-z0-9_-]{2,30}$/, hint: 'a.f.id.hint' },
      { key: 'icon', type: 'icon', label: 'a.f.icon', default: 'brain' },
      { key: 'name', type: 'i18n', label: 'a.f.name', required: true },
      { key: 'description', type: 'i18n', label: 'a.f.description' },
      { key: 'instruction', type: 'textarea', rows: 7, label: 'a.f.instruction', hint: 'a.f.instruction.hint', required: true },
      { key: 'model_tier', type: 'select', options: [{ value: 'fast', label: t('a.model.fast') }, { value: 'smart', label: t('a.model.smart') }], label: 'a.f.modelTier', hint: 'a.f.modelTier.hint' },
      { key: 'max_tokens', type: 'number', min: 100, max: 8000, required: true, label: 'a.f.maxTokens', hint: 'a.f.maxTokens.hint' },
      { key: 'min_tier', type: 'select', numeric: true, options: tierOptions(), label: 'a.f.minTier' },
      { key: 'sort', type: 'number', label: 'a.f.sort' },
      { key: 'active', type: 'check', label: 'a.f.active' },
    ],
    columns: [
      { label: 'a.f.name', render: r => h('div', { class: 'row-inline' }, icon(r.icon, 18), h('div', null, h('strong', null, tr(r.name)), h('div', { class: 'muted small', dir: 'ltr' }, r.id))) },
      { label: 'a.f.minTier', render: r => tierOptions().find(o => o.value === r.min_tier)?.label || r.min_tier },
      { label: 'a.f.modelTier', render: r => t('a.model.' + r.model_tier) },
      { label: 'a.f.maxTokens', render: r => fmt.num(r.max_tokens) },
      { label: 'a.f.active', render: r => yesNo(r.active) },
    ],
  });
}

async function settingsSection() {
  const cur = await api.admin.settings();
  const ann = cur.announcement || { enabled: false, text: {} };
  const rec = {
    site_name: cur.site_name || {}, announcement_enabled: !!ann.enabled, announcement_text: ann.text || {},
    trial_messages: cur.trial_messages ?? 0, max_history_messages: cur.max_history_messages ?? 16, max_input_chars: cur.max_input_chars ?? 4000,
    timezone: cur.timezone || 'Asia/Riyadh', contact_whatsapp: cur.contact_whatsapp || '', contact_email: cur.contact_email || '',
    payment_instructions: cur.payment_instructions || {}, private_system_base: cur.private_system_base || '',
    legal_terms: cur.legal_terms || {}, legal_privacy: cur.legal_privacy || {},
  };
  const form = buildForm([
    { key: 'site_name', type: 'i18n', label: 'a.s.siteName', required: true },
    { key: 'announcement_enabled', type: 'check', label: 'a.s.announceOn' },
    { key: 'announcement_text', type: 'i18n', label: 'a.s.announceText' },
    { key: 'payment_instructions', type: 'i18n', multiline: true, rows: 5, label: 'a.s.payment', hint: 'a.s.payment.hint' },
    { key: 'contact_whatsapp', label: 'a.s.whatsapp', ltr: true, hint: 'a.s.whatsapp.hint' },
    { key: 'contact_email', label: 'a.s.email', ltr: true },
    { key: 'trial_messages', type: 'number', min: 0, required: true, label: 'a.s.trial', hint: 'a.s.trial.hint' },
    { key: 'max_history_messages', type: 'number', min: 2, max: 60, required: true, label: 'a.s.history', hint: 'a.s.history.hint' },
    { key: 'max_input_chars', type: 'number', min: 100, max: 20000, required: true, label: 'a.s.maxChars' },
    { key: 'timezone', label: 'a.s.timezone', ltr: true, hint: 'a.s.timezone.hint' },
    { key: 'private_system_base', type: 'textarea', rows: 9, label: 'a.s.systemBase', hint: 'a.s.systemBase.hint' },
    { key: 'legal_terms', type: 'i18n', multiline: true, rows: 8, label: 'a.s.terms', hint: 'a.s.legal.hint' },
    { key: 'legal_privacy', type: 'i18n', multiline: true, rows: 8, label: 'a.s.privacy', hint: 'a.s.legal.hint' },
  ], rec, true);
  const save = h('button', { class: 'btn btn-primary', type: 'button', onclick: async () => {
    const v = form.read(); if (!v) return;
    const tz = v.timezone || 'Asia/Riyadh';
    try { new Intl.DateTimeFormat('en', { timeZone: tz }); } catch { form.fail(t('a.err.timezone')); return; }
    save.disabled = true;
    try {
      await api.admin.saveSettings({
        site_name: v.site_name, announcement: { enabled: v.announcement_enabled, text: v.announcement_text },
        payment_instructions: v.payment_instructions, contact_whatsapp: v.contact_whatsapp.replace(/[^\d]/g, ''), contact_email: v.contact_email,
        trial_messages: v.trial_messages, max_history_messages: v.max_history_messages, max_input_chars: v.max_input_chars,
        timezone: v.timezone || 'Asia/Riyadh', private_system_base: v.private_system_base,
        legal_terms: v.legal_terms, legal_privacy: v.legal_privacy,
      });
      await refreshCatalog(); toast(t('a.saved'), 'ok');
    } catch (e) { form.fail(String(e.raw?.message || e.message)); }
    save.disabled = false;
  } }, t('common.save'));
  return h('div', null, pageHead(t('a.nav.settings'), save), h('section', { class: 'card' }, form.el));
}

// ============================================================ الصفحة
export async function adminView(ctx) {
  const section = SECTIONS.some(s => s[0] === ctx.parts[0]) ? ctx.parts[0] : 'overview';
  const content = h('div', { class: 'admin-content' }, spinner(t('common.loading')));
  const nav = h('nav', { class: 'admin-nav', 'aria-label': 'admin' });
  const side = h('aside', { class: 'admin-side' },
    h('div', { class: 'admin-brand' }, h('span', { class: 'mark sm', 'aria-hidden': 'true' }, 'ر'), h('strong', null, t('a.title'))), nav,
    h('a', { class: 'nav-link back', href: '#/chat' }, icon('chat', 16), t('a.backToSite')),
    h('p', { class: 'credit sm' }, t('footer.credit')));
  const root = h('div', { class: 'admin' }, side, content);

  let stats = null;
  try { stats = await api.admin.stats(); } catch (e) { content.replaceChildren(h('div', { class: 'center-card' }, h('h2', null, t('a.err.noAccess')), h('p', { class: 'muted' }, t('a.err.noAccess.text')), h('code', null, String(e.message)))); return root; }

  nav.replaceChildren(...SECTIONS.map(([k, ic]) => h('a', { href: '#/admin/' + k, class: 'nav-link' + (k === section ? ' on' : '') },
    icon(ic, 18), h('span', null, t('a.nav.' + k)), k === 'orders' && Number(stats.pending_orders) > 0 ? h('span', { class: 'badge' }, fmt.num(stats.pending_orders)) : null)));

  const builders = { overview: () => overview(ctx, stats), orders: ordersSection, users: usersSection, plans: plansSection, offers: offersSection, modes: modesSection, thinking: thinkingSection, settings: settingsSection };
  try { content.replaceChildren(await builders[section]()); }
  catch (e) { console.error(e); content.replaceChildren(h('p', { class: 'form-error' }, String(e.message || e))); }
  return root;
}
